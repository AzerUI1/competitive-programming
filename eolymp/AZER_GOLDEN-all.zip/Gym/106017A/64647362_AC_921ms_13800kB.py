T = int(input())
for _ in range(T):
    N, K = map(int, input().split())
    a = list(map(int, input().split()))
    
    pairs = []  # store all sums
    for i in range(N):
        for j in range(N):
            pairs.append(a[i] + a[j])
    
    pairs.sort()
    print(pairs[K - 1])
