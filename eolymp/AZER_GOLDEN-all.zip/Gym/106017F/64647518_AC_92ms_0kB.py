import sys
data = sys.stdin.read().strip().split()
A = int(data[0]); X = int(data[1])

a = A
count = 0
p = 2
possible = True
while p * p <= a:
    while a % p == 0:
        if p > X:
            possible = False
        count += 1
        a //= p
    p += 1 if p == 2 else 2  # skip even numbers after 2

if a > 1:
    # a is a prime factor
    if a > X:
        possible = False
    count += 1

if not possible:
    print("Que es Obo?")
else:
    print(count)
 