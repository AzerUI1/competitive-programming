import sys, bisect
input = sys.stdin.readline

def count_pairs(a, x):
    # Count pairs (i, j) with a[i] + a[j] <= x
    n = len(a)
    cnt = 0
    for i in range(n):
        # We need j such that a[j] <= x - a[i]
        j = bisect.bisect_right(a, x - a[i])  # index after valid ones
        cnt += j
    return cnt

T = int(input())
for _ in range(T):
    N, K = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()

    low, high = a[0] + a[0], a[-1] + a[-1]

    # Binary search for smallest sum s with at least K pairs <= s
    while low < high:
        mid = (low + high) // 2
        if count_pairs(a, mid) >= K:
            high = mid
        else:
            low = mid + 1

    print(low)
