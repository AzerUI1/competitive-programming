import sys
input = sys.stdin.readline

def count_pairs(a, mid):
    n = len(a)
    j = n - 1
    cnt = 0
    for i in range(n):
        while j >= 0 and a[i] + a[j] > mid:
            j -= 1
        cnt += (j + 1)
    return cnt

T = int(input())
for _ in range(T):
    N, K = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()
    
    low = a[0] + a[0]
    high = a[-1] + a[-1]
    
    while low < high:
        mid = (low + high) // 2
        if count_pairs(a, mid) >= K:
            high = mid
        else:
            low = mid + 1
    
    print(low)
