
#include <bits/stdc++.h>
using namespace std;
int main() {
    string s;
    getline(cin, s);
    string f;
    for (char c : s) {
        if (c != ' ') {
            f += c;
        }
    }
    string r = f;
    reverse(r.begin(), r.end());
    if (f == r) {
        cout << "YES";
    } else {
        cout << "NO";
    }
    return 0;
}