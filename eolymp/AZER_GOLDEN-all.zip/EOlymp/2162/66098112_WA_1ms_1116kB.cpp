#include <bits/stdc++.h> 
using namespace std; 
bool palindrome(string s) {
    string temp = s; 
    reverse(temp.begin(), temp.end());
    if (temp == s) {
        return true; 
    } else {
        return false;
    }
}
int main(void) {
    string s; getline(cin, s);
    if (palindrome(s)) {
        cout << "YES" << endl; 
    } else {
        cout << "NO" << endl; 
    }
    return 0; 
}