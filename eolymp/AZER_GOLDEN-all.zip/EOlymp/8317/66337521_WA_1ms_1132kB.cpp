/*
    Author: Azer Aslanov
*/ 

#include <bits/stdc++.h> 

typedef long long unsigned int ll;

using namespace std; 

/*
void function() {
    
}
*/

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
	ll n; cin >> n;
	string s = to_string(n);
	sort(s.begin(), s.end());
	//cout << "string: " << s << endl; 
	ll min = stoll(s);
	ll ans =  (n - min) * (n - min);
	cout << ans << endl; 
    return 0;
}