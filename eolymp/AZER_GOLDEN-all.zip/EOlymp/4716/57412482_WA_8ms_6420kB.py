# Input: Two integers n (students) and k (apples)
n = int(input("Enter the number of students: "))
k = int(input("Enter the number of apples: "))

# Calculate apples per student
apples_per_student = k // n

# Output the result
print(apples_per_student)
