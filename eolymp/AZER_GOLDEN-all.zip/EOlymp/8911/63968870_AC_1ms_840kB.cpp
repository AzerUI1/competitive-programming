#include <iostream>
using namespace std; 
int main() { 
  long long n; 
  long long sum = 0;
  while (cin >> n && n != 0) {
    if (n < 0) { 
      sum++; 
    }
  }
  cout << sum << endl;
}