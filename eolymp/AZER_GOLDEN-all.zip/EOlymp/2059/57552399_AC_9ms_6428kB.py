n = int(input())
a  = n - 1 # -*- coding: latin-1 -*-print(a)
print(a)