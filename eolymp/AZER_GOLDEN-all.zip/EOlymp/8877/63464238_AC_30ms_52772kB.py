import math
n = int(input())
m = int(math.sqrt(n))
if m * m == n:
    print(m)
else: 
    print("No")