a, b = map(int, input().split()) 
k = (a + b) / 2 
if k == int(k):
    print(k) 
else: 
    print("-")
