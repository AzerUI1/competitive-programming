a, b = map(int, input().split())
s = a + b
if s % 2 == 0:
    k = s // 2   # Целочисленное деление
    print(k)
else:
    print("-")
