#include <bits/stdc++.h>
using namespace std;

int main() { 
    int m;
    cin >> m;
    int hours = m / 60;
    int minutes = m % 60;
    cout << hours << " " << minutes << endl;
    return 0; 
}