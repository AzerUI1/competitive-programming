# cook your dish here
import math
a,b = map(int, input().split())
c = a + b
result = c * c
print(result)