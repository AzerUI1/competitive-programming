# cook your dish here
number = int(input())
tens = number // 10  
ones = number % 10  
number2 = tens + ones
result = number2 * number2
print(result)