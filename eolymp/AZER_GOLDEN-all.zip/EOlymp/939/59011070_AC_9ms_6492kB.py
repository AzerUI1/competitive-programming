n = int(input())  # Read a two-digit integer
digit1 = n // 10  # Extract the tens place digit
digit2 = n % 10   # Extract the ones place digit
result = (digit1 + digit2) ** 2  # Square the sum of digits
print(result)  # Print the result
