n = input() 
a = int(n[0])
b = int(n[1]) 
c = a + b 
d = c * c
print(d)