# OlympicTasksPython 
import math
data = input().split()
area = float(data[0])
R = float(data[1])

r = math.sqrt(R**2 - area / math.pi)

print("{:.2f}".format(r))