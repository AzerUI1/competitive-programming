d1, d2, d3 = map(int, input().split())
result = min(
    2 * (d1 + d2),
    d1 + d2 + d3,
    2 * (d1 + d3),
    2 * (d2 + d3)
)
print(result)
