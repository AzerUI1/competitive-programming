from collections import deque

def min_pours(M):
    max_capacity = 100
    visited = [False] * (max_capacity + 1)
    queue = deque()
    queue.append((0, 0))  
    visited[0] = True

    while queue:
        current, pours = queue.popleft()

        if current == M:
            return pours

        for delta in [3, 5, -3, -5]:
            next_val = current + delta
            if 0 <= next_val <= max_capacity and not visited[next_val]:
                visited[next_val] = True
                queue.append((next_val, pours + 1))

    return -1 

M = int(input())
print(min_pours(M))
