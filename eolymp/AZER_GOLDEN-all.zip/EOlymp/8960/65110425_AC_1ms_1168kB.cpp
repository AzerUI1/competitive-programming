#include <iostream>
using namespace std; 

int main() {
    int n; cin >> n;
    int a[n];
    int max = -100, min = 100;
    int sum = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    for (int i = 0; i < n; i++) {
        if (a[i] > max) max = a[i];
        if (a[i] < min) min = a[i];
    }
    for (int i = 0; i < n; i++) {
        if (a[i] != max && a[i] != min) sum += a[i];
    }
    cout << sum;
}