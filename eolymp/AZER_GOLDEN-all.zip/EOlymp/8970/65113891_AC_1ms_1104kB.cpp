#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main() {
    ll n;
    cin >> n;
    ll ev = (n + 1) / 2; 
    ll od = n - ev;      
    vector<ll> a(n); 
    ll x;
    for (int i = 0; i < ev; i++) {
        cin >> x;
        a[i * 2] = x;
    }
    for (int i = 0; i < od; i++) {
        cin >> x;
        a[i * 2 + 1] = x;
    }
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    return 0;
}
