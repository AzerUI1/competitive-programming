from itertools import combinations

def can_accommodate(k, w, tents):
    for r in range(1, 4):  # Количество палаток в комбинации (1, 2 или 3)
        for combo in combinations(tents, r):
            total_weight = sum(t[0] for t in combo)
            total_capacity = sum(t[1] for t in combo)
            if total_weight <= w and total_capacity >= k:
                return "YES"
    return "NO"

# Чтение входных данных
k, w = map(int, input().split())
tents = []
data = list(map(int, input().split()))
for i in range(0, 6, 2):
    tents.append((data[i], data[i+1]))  # Формируем список кортежей (вес, вместимость)

# Вывод результата
print(can_accommodate(k, w, tents))
