k, w = map(int, input().split()) 
a = list(map(int, input().split()))  
b = list(map(int, input().split())) 
if sum(a) <= k:
    if sum(b) <= w: 
        print("YES") 
if sum(b): 
    if sum(a): 
        print("YES") 
else:
    print("NO")