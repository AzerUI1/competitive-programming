#include <bits/stdc++.h>
using namespace std;

int main() {
    string s;
    getline(cin, s);
    string r;
    for (char c : s) {
        if (c >= 'a' && c <= 'z') {
            r += c;
            r += c;
        } else {
            r += c;
        }
    }
    cout << r << endl;
    return 0;
}