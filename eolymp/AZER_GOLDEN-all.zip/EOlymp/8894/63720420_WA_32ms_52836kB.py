n = int(input())
if n % 3 == 0 and n % 2 == 0 and 10 <= abs(n) <= 99:
    print("NO")
else:
    print("YES")
