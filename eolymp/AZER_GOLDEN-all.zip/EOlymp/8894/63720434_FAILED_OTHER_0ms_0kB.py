n = int(input())

if (n % 2 == 0 and n > 0) or (n % 2 != 0 and n < 0):
    print("NO")
else:
    print("YES")
