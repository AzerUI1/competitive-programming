#include <iostream>
#include <algorithm> 
using namespace std;
typedef long long ll;
int main() {
    ll n; cin >> n;
    if (n < 0) { 
        n = -n; 
    }
    while(n >= 0) { 
        cout << n << " " << "sek\n"; 
        --n; 
    }
    return 0; 
}