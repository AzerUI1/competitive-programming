#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;
int main() { 
    ll n; cin >> n;
    while (n > 0) { 
        cout << n % 10;
        n /= 10;
    }
    return 0;
}