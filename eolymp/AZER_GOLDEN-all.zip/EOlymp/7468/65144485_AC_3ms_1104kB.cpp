#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main() {
    int n; cin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        cin >> v[i];
    }
    int i = 0, j = n - 1; 
    while (i < j) {
      cout << v[i] << " " << v[j] << " ";
      i++;
      j--;
    }
    if (i == j) {
      cout << v[j];
    }
} 