#include <iostream>
using namespace std;

typedef long long ll;

int main(){
    ll x, y;
    cin >> x >> y;

    for(int i = 1; i <= 1000000; i++){ 
        ll n = i;
        ll cem = 0;
        ll k = 0;

        while(n > 0){
            cem += n % 10; 
            n /= 10;
            k++; 
        }

        if(x == k && y == cem){
            cout << i << endl;
        }
    }
    
    return 0;
}