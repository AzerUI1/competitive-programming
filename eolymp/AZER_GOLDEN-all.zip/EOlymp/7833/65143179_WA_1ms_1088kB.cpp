#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n; cin >> n;
    vector<int> a(n);
    int sum = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        sum += a[i];
    }
    double av = sum / n;
    int count = 0;
    int sum2 = 0;
    for (int i = 0; i < n; i++)
        if (a[i] > av) {
            count++;
            sum2 += a[i];
        }
    cout << sum2 << " " << count;
}