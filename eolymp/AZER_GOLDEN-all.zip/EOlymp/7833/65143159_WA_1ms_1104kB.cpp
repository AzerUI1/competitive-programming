#include <bits/stdc++.h>
using namespace std;

int main(void) {
        long long n, s = 0; cin >> n;
        vector<long long> a(n);
        for (int i = 0; i < n; i++) {
                cin >> a[i];
                s += a[i];
        }
        long long c = 0;
        long long s1 = 0;
        double av = s / n;
        for (int i = 0; i < n; i++) {
                if (a[i] > av) {
                        c += 1;
                        s1 += a[i];
                }
        }
        cout << s1  << " "  << c << endl;
        return 0;
}
