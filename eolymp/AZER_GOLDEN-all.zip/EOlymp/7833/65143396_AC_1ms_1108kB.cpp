#include <iostream>
#include <vector>
using namespace std; 

int main() {
    int n; 
    cin >> n;
    vector<int> m(n);
    int s = 0;
    for (int i = 0; i < n; i++) {
        cin >> m[i];
        s += m[i];
    }
    int su = 0;
    int c = 0;
    for (int i = 0; i < n; i++) {
        if (m[i] * n > s) {
            su += m[i];
            c++;
        }
    }
    cout << su << " " << c << endl;
}