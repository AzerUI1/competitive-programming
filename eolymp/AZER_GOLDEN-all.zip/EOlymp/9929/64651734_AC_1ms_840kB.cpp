#include <bits/stdc++.h>
using namespace std;

int main() { 
    long long m;
    cin >> m;
    cout << m / 1000 << " " << m % 1000;
    return 0; 
}