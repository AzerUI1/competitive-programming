# Read the mobile phone number as input
phone_number = input().strip()

# Set of all digits from 0 to 9
all_digits = set('0123456789')

# Set of digits present in the phone number
present_digits = set(phone_number)

# Find missing digits by subtracting present digits from all digits
missing_digits = sorted(all_digits - present_digits)

# Output the number of missing digits
print(len(missing_digits))

# Output the missing digits in ascending order
if missing_digits:
    print(" ".join(missing_digits))
else:
    print()  # If no digits are missing, just print an empty line
