/*
    Author: Azer Aslanov
*/ 

#include <bits/stdc++.h> 

using namespace std; 

/*
void function() {
    
}
*/

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

	vector<int> count(10, 0); 

	while (true) {
		int n; cin >> n; 
		if (n == 0) break;
		count[n]++;
	}

	int maxi = 0; 

	for (int i = 0; i < 10; i++) { 
		if (count[i] > count[maxi]) {
			maxi = i; 
		}
	}

	cout << maxi << endl << count[maxi] << endl;

    return 0;
}