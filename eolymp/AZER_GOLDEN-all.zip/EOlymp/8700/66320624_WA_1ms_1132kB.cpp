/*

*/

/*
    Author: Azer Aslanov
*/

#include <bits/stdc++.h>
typedef long long ll;

using namespace std;

/*
void function() {

}
*/

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);

	vector<ll> v;
	ll x;
	map<ll, ll> fr;
	ll max = 0;
	ll ans = 0;

	while (cin >> x) {
		v.push_back(x);
	}

	for (ll i = 0; i < v.size(); i++) {
		fr[v[i]]++;
	}

	for (auto i : fr) {
		if (i.second > max) {
			max = i.second;
			ans = i.first;
		}
	}

	cout << ans << endl;
	cout << max << endl;

	return 0;
}