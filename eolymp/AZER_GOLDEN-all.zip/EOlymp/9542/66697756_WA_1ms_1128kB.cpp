/*
  Find the largest positive integer which product of digits equals to the positive integer m, or print -1 if there no such number. Numbers that contain digits 0 and 1 are not considered.

  Input
  One integer m (2 ≤ m ≤ 10^3).

  Output
  Print the largest positive integer which product of digits equals to m. Print -1 if such number does not exist.

  Examples
  Inputcopy	Outputcopy
  12
  322

*/ 

/*
    Author: Azer Aslanov
*/

#include <bits/stdc++.h>
using namespace std;

#define FAST ios::sync_with_stdio(false); cin.tie(nullptr);

#define ll long long
#define ull unsigned long long
#define ld long double
#define pii pair<int,int>
#define pll pair<long long,long long>
#define vi vector<int>
#define vll vector<long long>
#define vb vector<bool>
#define vpi vector<pair<int,int>>
#define vpll vector<pair<long long,long long>>

#define rep(i,a,b) for (int i = (a); i < (b); i++)
#define rrep(i,a,b) for (int i = (a); i >= (b); i--)
#define each(x,a) for (auto &x : a)

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define pb push_back
#define mp make_pair
#define ff first
#define ss second

const ll INF = 9e18;
const int MOD = 1000000007;
const int MOD2 = 998244353;

#define bitcount(x) __builtin_popcount(x)
#define bitcountll(x) __builtin_popcountll(x)
#define clz(x) __builtin_clz(x)
#define clzll(x) __builtin_clzll(x)
#define ctz(x) __builtin_ctz(x)
#define ctzll(x) __builtin_ctzll(x)

#ifdef LOCAL
#define debug(x) cerr << #x << " = " << x << endl
#else
#define debug(x)
#endif

ll power(ll a, ll b, ll mod = MOD) {
  ll r = 1;
  while (b) {
    if (b & 1) r = (r * a) % mod;
    a = (a * a) % mod;
    b >>= 1;
  }
  return r;
}

ll gcdll(ll a, ll b) {
  return b == 0 ? a : gcdll(b, a % b);
}
ll lcmll(ll a, ll b) {
  return a / gcdll(a, b) * b;
}

long long even(long long n) {
  return n % 2 == 0;
}

ll factorial(ll n) {
  if (n == 0 || n == 1) return 1;
  return n * factorial(n - 1);
}


ll sum(ll n) {
  ll res = 0;
  while (n) {
    res += n % 10;
    n /= 10;
  }
  return res;
}

bool getout(string s) {
  if (s.find('1') != string::npos && s.find('0') != string::npos) {
    return false;
  } else {
    return true;
  }
}

int main() {
  FAST;
  ll m; cin >> m; 
  if (m == 1 || m == 0) {
    cout << -1 << endl;
    return 0;
  }
  string ans;
  bool found = false;
  for (ll i = 1e3; i >= 2; i--) {
    ll temp = i;
    ll mlt = 1;
    while (temp) {
      mlt *= temp % 10;
      temp /= 10;
    }
    if (mlt == m) {
      ans = to_string(i); 
      found = true;
      break;
    } else {
      continue;
    }
  }
  if (found) {
    cout << ans << endl;
  } else {
    cout << -1 << endl;
  }
  return 0;
}