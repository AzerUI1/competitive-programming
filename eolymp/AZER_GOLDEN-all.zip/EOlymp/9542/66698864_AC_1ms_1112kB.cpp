#include <bits/stdc++.h>
using namespace std;

int main() {
    int m;
    cin >> m;

    string result = "";

    while (m % 2 == 0) {
        result += '2';
        m /= 2;
    }
    while (m % 3 == 0) {
        result += '3';
        m /= 3;
    }
    while (m % 5 == 0) {
        result += '5';
        m /= 5;
    }
    while (m % 7 == 0) {
        result += '7';
        m /= 7;
    }

    if (m != 1) {
        cout << -1;
        return 0;
    }

    sort(result.rbegin(), result.rend());

    cout << result;
    return 0;
}
