#include <bits/stdc++.h>
#define ll long long 
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    ll n; cin >> n; 
    ll a[n]; 
    ll b[n]; 
    for (ll i = 0; i < n; i++) {
        cin >> a[i]; 
        b[i] = a[i]; 
    }
    sort(a, a + n); 
    ll ans = -1; 
    for (ll i = 0; i < n; i++) {
        if (a[i]!=b[i]) {
            ans++; 
        }
    }  
    cout << ans << "\n"; 
    return 0;
}
