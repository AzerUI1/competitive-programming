/*
    Farmer John is feeling ambitious. He wants to do something that never seems to go quite right: take a photograph of his entire herd of cows.

    To make the photograph look nice, he asks the cows to line up in a single row from shortest to tallest. Unfortunately, right after he has the cows lined up, Bessie the cow—always the troublemaker—steps out of line and re-inserts herself at a different position in the lineup!

    Farmer John now wants to swap pairs of cows so that the entire herd is again lined up properly, from shortest to tallest. Please help him determine the minimum number of swaps he needs to make between pairs of cows to correct the order. The swaps do not need to involve adjacent cows.

    Input
    The first line contains a single integer 
    n
    n (
    2
    ≤
    n
    ≤
    100
    2≤n≤100), the number of cows. Each of the next 
    n
    n lines contains an integer denoting the height of a cow in the current lineup, after Bessie has changed places. Each height is an integer from 
    1
    1 to 
    10
    6
    10 
    6
     . Cows may have the same height.

    Output
    Output a single integer: the minimum number of swaps Farmer John must perform between pairs of cows to return the lineup to the proper sorted order.

    Examples
    In the following example, Bessie is clearly the cow with height 
    3
    3. Farmer John returns the cows to sorted order using three swaps as shown:

    2 4 7 7 9 3 — Original lineup

    2 4 7 7 3 9 — Swap the last two cows

    2 4 3 7 7 9 — Swap the first 
    7
    7 and 
    3
    3

    2 3 4 7 7 9 — Swap 
    4
    4 and 
    3
    3

    Inputcopy	Outputcopy
    6
    2
    4
    7
    7
    9
    3
    3


*/ 


/**
  * @authr: Azer Aslanov;
*/

#include <bits/stdc++.h>
using namespace std;

#define FAST ios::sync_with_stdio(false); cin.tie(nullptr);

#define ll long long
#define ull unsigned long long
#define ld long double
#define pii pair<int,int>
#define pll pair<long long,long long>
#define vi vector<int>
#define vll vector<long long>
#define vb vector<bool>
#define vpi vector<pair<int,int>>
#define vpll vector<pair<long long,long long>>

#define rep(i,a,b) for (int i = (a); i < (b); i++)
#define rrep(i,a,b) for (int i = (a); i >= (b); i--)
#define each(x,a) for (auto &x : a)

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define pb push_back
#define mp make_pair
#define ff first
#define ss second

const ll INF = 9e18;
const int MOD = 1000000007;
const int MOD2 = 998244353;

#define bitcount(x) __builtin_popcount(x)
#define bitcountll(x) __builtin_popcountll(x)
#define clz(x) __builtin_clz(x)
#define clzll(x) __builtin_clzll(x)
#define ctz(x) __builtin_ctz(x)
#define ctzll(x) __builtin_ctzll(x)

#ifdef LOCAL
#define debug(x) cerr << #x << " = " << x << endl
#else
#define debug(x)
#endif

ll power(ll a, ll b, ll mod = MOD) {
    ll r = 1;
    while (b) {
        if (b & 1) r = (r * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return r;
}

ll gcdll(ll a, ll b) { return b == 0 ? a : gcdll(b, a % b); }
ll lcmll(ll a, ll b) { return a / gcdll(a, b) * b; }

string square_string(string s) {
    int n = s.size();
    vector<int> res(2*n, 0);

    reverse(s.begin(), s.end());

    for (int i = 0; i < n; i++) {
        int a = s[i] - '0';
        for (int j = 0; j < n; j++) {
            int b = s[j] - '0';
            res[i + j] += a * b;
        }
    }


    for (int i = 0; i < 2*n; i++) {
        if (res[i] >= 10) {
            res[i+1] += res[i] / 10;
            res[i] %= 10;
        }
    }

    int i = 2*n - 1;
    while (i > 0 && res[i] == 0) i--;

    string ans = "";
    while (i >= 0) {
        ans += char(res[i] + '0');
        i--;
    }

    return ans;
}

bool cmp(pair<string, int>& a, pair<string, int>& b) { 
    return a.second < b.second; 
} 

void sort(map<string, int>& M) { 

    vector<pair<string, int>> A; 

    for (auto& it : M) { 
        A.push_back(it); 
    } 

    sort(A.begin(), A.end(), cmp); 

    for (auto& it : A) { 

        cout << it.first << ' ' << it.second << endl; 
    } 
} 

void solve() {
    ll n; cin >> n;
    vll a(n);
    rep(i, 0, n) cin >> a[i];
    vll b = a; 
    sort(all(b));
    ll ans = 0;
    for (ll i = 0; i < n; i++) {
        if (a[i] != b[i]) {
            ll j = i + 1;
            while (a[j] != b[i]) j++;
            swap(a[i], a[j]);
            ans++;
            if (a[i] != b[i]) i--;
            else ans++;
        }
    }
    cout << ans << endl;
}

int main() {
    FAST; 
    solve(); 
    return 0; 
}