#include <bits/stdc++.h>
using namespace std;

int main() {
    string s; getline(cin ,s); 
    int count2 = 0, count5 = 0;
    for (char c : s) {
        if (c == '2') count2++;
        else if (c == '5') count5++;
    }
    if (count2 > count5) cout << 2 << endl;
    else if (count5 > count2) cout << 5 << endl;
    else cout << "=" << endl;
    return 0; 
}