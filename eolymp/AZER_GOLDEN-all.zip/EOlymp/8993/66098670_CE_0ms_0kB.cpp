#include <bits/stdc++.h>
#define int long long
using namespace std;
int main() {
    string a, b;
    getline(cin, a);
    getline(cin, b);
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    if (a == b) {
        cout << "YES\n";
    } else {
        cout << "NO\n";
    }
    return 0;
} 