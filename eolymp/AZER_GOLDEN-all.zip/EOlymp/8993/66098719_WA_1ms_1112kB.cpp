#include <bits/stdc++.h>
using namespace std;
int main() {
    string a, b; 
    getline(cin, a); 
    getline(cin, b); 
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());//dfqaf
    if (a.find(b) != string::npos) {
        cout << "Ok" << endl;
    } else {
        cout << "No" << endl;
    }
}