#include <bits/stdc++.h>
using namespace std;
int main() {
    string a, b; 
    getline(cin, a); 
    getline(cin, b); 
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    for (char i : b) {
        for (char j : a) {
            if (i == j) {
                a.erase(find(a.begin(), a.end(), j));
                break;
            }

        }//s

    }
    if (b.size() > a.size() + b.size()) { 
        cout << "No" << endl;
    } else {
        cout << "Ok" << endl;
    }
}