#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string a, b; 
    cin >> a >> b;
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    int j = 0;
    int i = 0;
    while (i < b.size()) {
        if (a[j] == b[i]) {
            i++;
            j++;
        } else if (a[j] < b[i]) {
            j++; 
        } else if (a[j] > b[i]) {
            cout << "No" << endl; 
            return 0; 
        }
    } 
    cout << "Ok" << endl; 
}