#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string a, b; 
    getline(cin, a); 
    getline(cin, b); 
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    int j = 0;
    int i = 0;
    while (i < b.size()) {
        if (a[j] == b[i]) {
            j++;
            i++;
        } else if (a[j] < b[i]) {
            j++; 
        } else if (a[j] > b[i]) {
            cout << "NO" << endl; 
            return 0; 
        }
    } 
    cout << "Ok" << endl; 
}