t = int(input()) 
for i in range(t): 
    n = int(input())
    a, b = 1, 1
    for j in range(3, n+1): 
        a, b = b, a + b
    print(b)
  