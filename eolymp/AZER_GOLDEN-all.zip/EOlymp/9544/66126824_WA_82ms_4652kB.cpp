#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string s;
    cin >> s;
    int cnt = 0;
    int n = s.size();
    while (1)
    {
        if (n % 2 == 1) {
            cout << cnt << endl; 
            for (int i = 0; i < n; i++) {
                cout << s[i];
            }
            return 0; 
    }

        for (int i = 0; i < n / 2; i++) {
            if (s[i] != s[n - 1 - i]) {
                cout << cnt << endl; 
                for (int j = 0; j < n; j++) {
                    cout << s[j];
                }
                return 0;
            }
        }
        cnt++;
        n /= 2;
    }    
}