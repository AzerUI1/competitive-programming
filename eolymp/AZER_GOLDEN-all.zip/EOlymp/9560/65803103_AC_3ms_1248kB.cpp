#include <bits/stdc++.h> 
using namespace std;

int main() { 
    long long n, m; cin >> n >> m;
    long long a[n][m]; 
    long long b[n];
    for (long long i = 0; i < n; i++) { 
        for (long long j = 0; j < m; j++) { 
            cin >> a[i][j]; 
        } 
    }
    for (long long i = 0; i < n; i++) { 
        for (long long j = 0; j < m; j++) { 
            cout << a[i][j] << " "; 
        } 
        cout << endl;
    }
    return 0; 
}