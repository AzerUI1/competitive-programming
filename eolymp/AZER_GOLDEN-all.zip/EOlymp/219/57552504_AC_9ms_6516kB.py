import math

def minimum_radiators(h, w, l, k):
    # Calculate the total volume of the room
    volume = h * w * l
    
    # Calculate the minimum number of radiators required
    radiators = (volume + k - 1) // k
    
    return radiators

# Input
h, w, l, k = map(int, input().split())

# Output
print(minimum_radiators(h, w, l, k))
