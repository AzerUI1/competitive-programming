# Olympic Tasks Python
h, w, l, k = map(int, input().split())
a = h * w * l
if a % k == 0:
    print(a // k)
else:
    print(a // k + 1)