#include <iostream>
#include <string> 
#include <algorithm>  
typedef long long ll;
using namespace std; 
int main(void) { 
  ll n; cin >> n; 
  for (ll i = 1; i <= n; i++) { 
    cout << i * i << endl;
  }
  return 0; 
}