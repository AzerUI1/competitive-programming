#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;
int main() { 
    ll n; cin >> n;
    ll sum = 0;
    while (n > 0) {
        ll digit = n % 10;
        if (digit % 2 == 0) {
            sum += digit;
        }
        n /= 10;
    }
    if (sum == 0) {
        cout << -1 << endl;
    } else {
        cout << sum << endl;
    }
    return 0;
}