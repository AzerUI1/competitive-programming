#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;
int main() { 
    ll n, sum = 0; cin >> n;
    while (n > 0) { 
        ll digit = n % 10;
        if (digit % 2 == 0) {
            sum += digit;
        } else { 
            sum = -1; 
        }
        n /= 10;
    }
    cout << sum << endl;
    return 0;
}