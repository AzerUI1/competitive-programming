#include <iostream>
using namespace std;

int main() {
    long long n; 
    cin >> n;
    int sum = 0;
    bool found = false;
    while (n > 0) {
        int d = n % 10;
        if (d % 2 == 0) {
            sum += d;
            found = true;
        }
        n /= 10;
    }
    if (!found) cout << -1;
    else cout << sum;
}
