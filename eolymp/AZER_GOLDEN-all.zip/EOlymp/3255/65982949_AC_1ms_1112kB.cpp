#include <bits/stdc++.h> 
using namespace std;

int main() {
    string s; getline(cin, s);
    long long res = s[0] - '0';  
    for (size_t i = 1; i < s.size(); i += 2) {
        if (s[i] == '+') {
            res += (s[i + 1] - '0');
        } else if (s[i] == '*') {
            res *= (s[i + 1] - '0');
        }   
    }
    cout << res << endl;
    return 0;  
}