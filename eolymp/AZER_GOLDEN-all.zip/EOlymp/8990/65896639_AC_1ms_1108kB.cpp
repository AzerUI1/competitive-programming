#include <iostream>
#include <string>
using namespace std;
int main() {
    string s;
    getline(cin, s);
    string r;
    for (char c : s) {
        r += c;
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'y') {
            r += c;
        }
    }
    cout << r << endl;
    return 0;
}