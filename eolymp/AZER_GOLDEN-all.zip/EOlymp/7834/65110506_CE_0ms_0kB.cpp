int main() {
    int n;cin >> n; 
    int a[n];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    int max = -1000000000; 
    int min = 1000000000;
    for (int i = 0; i < n; i++) {
        if (a[i] > max) {
            max = a[i];
        }
        if (a[i] < min) { 
            min = a[i];
        }
    } 
    int sum = 0; 
    for (int i = 0; i < n; i++) {
        if (a[i] != max && a[i] != min) {
            sum += a[i];
        }
    }
    cout << sum << endl;
}