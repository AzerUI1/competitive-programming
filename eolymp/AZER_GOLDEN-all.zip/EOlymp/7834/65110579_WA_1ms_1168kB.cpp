#include <iostream>
using namespace std; 
int main() {
    int n; cin >> n; 
    int a[n];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    int max = -1000000000; 
    int max2 = -1000000000;
    for (int i = 0; i < n; i++) { 
        if (a[i] > max) { 
            max2 = max;
            max = a[i];
            continue;
        }
    }
    cout << max + max2;
}