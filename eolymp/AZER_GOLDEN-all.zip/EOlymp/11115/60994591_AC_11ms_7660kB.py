# OlympicTasksPython

a, b = map(int, input().split())  # Vvod razmerov (ne ispol'zuyutsya)
n = list(map(int, input().split()))  # Pervyy nabor
m = list(map(int, input().split()))  # Vtoroy nabor

for x in range(1, 10):         # Proveryaem tsifry ot 1 do 9
    if x in n and x in m:      # Esli tsifra est' v oboih naborah
        print(x)               # Eto luchshiy otvet
        exit()                 # Vykhod

a = min(n)  # Min tsifra iz pervogo nabora
b = min(m)  # Min tsifra iz vtorogo nabora

if a > b:   # Delaem men'shee chislo pervym
    a, b = b, a

print(a * 10 + b)  # Vivodim samoe malen'koe dvuznachnoe chislo
