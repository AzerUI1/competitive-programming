# OlympicTasksPython

a, b = map(int, input().split())  # Vvod razmerov dvuh naborov (ne ispol'zuyutsya dalee)

n = list(map(int, input().split()))  # Pervyy nabor tsifr
m = list(map(int, input().split()))  # Vtoroy nabor tsifr

for x in n:           # Proveryaem kazhduyu tsifru iz pervogo nabora
    if x in m:        # Esli ona est' i vo vtorom
        print(x)      # To eto samoe malen'koe vozmozhnoe krasivoe chislo
        exit()        # Vyhod, tak kak my uzhe nashli otvet

a = min(n)  # Min tsifra iz pervogo nabora
b = min(m)  # Min tsifra iz vtorogo nabora

if a > b:   # Delaem men'shee chislo pervym
    a, b = b, a

print(a * 10 + b)  # Vivodim dvuznachnoe chislo bez f-stroki
