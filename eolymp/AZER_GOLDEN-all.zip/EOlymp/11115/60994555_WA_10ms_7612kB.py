# OlympicTasksPython
a, b = map(int, input().split()) 
n = list(map(int, input().split())) 
m = list(map(int, input().split())) 
a = min(n)
b = min(m)
if a > b: 
    a, b = b, a
print(f"{a}{b}") 