import math

# Input: number of boys (n), girls (m), and beds per room (k)
n, m, k = map(int, input().split())

# Calculate rooms needed for boys and girls
rooms_for_boys = math.ceil(n / k)
rooms_for_girls = math.ceil(m / k)

# Total rooms needed
total_rooms = rooms_for_boys + rooms_for_girls

# Output the total number of rooms
print(total_rooms)
