n, m, k = map(int, input().split())
rb = n / k
rg = m / k
tr = rb + rg
print(tr)
