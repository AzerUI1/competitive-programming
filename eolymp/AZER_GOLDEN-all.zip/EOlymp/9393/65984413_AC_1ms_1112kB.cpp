#include <bits/stdc++.h>
using namespace std;

int main() {
    string s; getline(cin, s);
    string r; 
    for (char c : s) {
        if (!isdigit(c) || (c - '0') % 2 == 0) {
            r += c;
        }
    }
    cout << r << endl;
    return 0;
}