# OlympicTasksPython
a, b = map(int, input().split()) 
c = ((a + b + 1) ** b)  998244353
print(c) 