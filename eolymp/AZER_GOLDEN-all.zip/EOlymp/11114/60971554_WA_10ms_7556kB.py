n, m = map(int, input().split())
MOD = 998244353

k = min(n, m)
res = pow(n + m + 1, k, MOD)
print(res)
