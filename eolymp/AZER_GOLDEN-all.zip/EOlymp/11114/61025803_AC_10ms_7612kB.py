n, m = map(int, input().split())

n = n*2+1
k = n

for i in range(m-1):
    n = n * k
    n %= 998244353

print(n)