a, b = map(int, input().split())
MOD = 998244353
c = pow(a + b + 1, b, MOD)
print(c)
