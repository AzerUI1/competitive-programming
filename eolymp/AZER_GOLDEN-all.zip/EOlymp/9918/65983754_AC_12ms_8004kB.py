n = int(input())
t = input()
print(' '.join([t] * n))