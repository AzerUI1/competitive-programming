#include <bits/stdc++.h>
using namespace std;

int main() {
    long long n; cin >> n;
    string s;
    getline(cin, s); 
    for (long long i = 0; i < n; i++) {
        if (i) { 
            cout << " ";
        }
        cout << s;
    }   
    return 0;
}