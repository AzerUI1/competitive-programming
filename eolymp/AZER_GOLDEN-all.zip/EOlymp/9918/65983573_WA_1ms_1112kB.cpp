#include <bits/stdc++.h>
using namespace std;

int main() {
    long long n; cin >> n;
    string s;
    getline(cin, s);
    for (int i = 0; i < n; i+=1) {
        cout << s << " ";
    }
    return 0;
}