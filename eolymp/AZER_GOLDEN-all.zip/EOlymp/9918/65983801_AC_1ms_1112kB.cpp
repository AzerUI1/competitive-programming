#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    string t;
    cin >> n;
    cin >> t;
    for (int i = 0; i < n; i++) {
        cout << t;
        if (i < n - 1) {
            cout << " ";
        }
    }
    cout << endl;
    return 0;
}