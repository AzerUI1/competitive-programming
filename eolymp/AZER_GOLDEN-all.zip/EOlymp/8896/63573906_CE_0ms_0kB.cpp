n = input()  
if n[0] == n[1] or n[0] == n[2] or n[1] == n[2]: 
    print("NO")
    
else: 
    print("YES")