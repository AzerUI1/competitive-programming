a = input() 
a1 = a[0]
a2 = a[1]
a3 = a[2]
if (a1 == a2 or a2 == a3 or a1 == a3 or a1 == a2 == a3): 
    print("NO")
else: 
    print("YES")