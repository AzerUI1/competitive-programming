/*
    Author: Azer Aslanov
*/ 

#include <bits/stdc++.h> 

using namespace std; 

/*
void function() {
    
}
*/

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

	int count = 0, max = 0; 

	vector<int> v;

	while (true) {
		int n; cin >> n; 

		v.push_back(n);
		count++;
		if (v.size() >= 3) {
			int size = v.size();
			if (v[size - 1] == v[size - 2] && v[size - 2] == v[size - 3]) {
				cout << count << endl;
				break;
			}
		}
	}

    return 0;
}