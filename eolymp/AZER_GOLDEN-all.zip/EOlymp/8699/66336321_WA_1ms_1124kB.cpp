/*
    Author: Azer Aslanov
*/ 

#include <bits/stdc++.h> 
typedef long long ll;

using namespace std; 

/*
void function() {
	
}
*/

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    vector<ll> v; ll x; 
	ll count = 1; ll max = 0;
	ll elms = 0; 

    while (cin >> x) {
		v.push_back(x); 
		elms++;
		for (ll i = v.size() - 2; i >= 0; i--) {
			if (v[i] == v[i + 1]) {
				count++;
				if (count >= 3) {
					cout << elms << "\n"; 
					return 0; 
				}
			} else {
				count = 1; 
				break; 
			}
		}
	} 

    return 0;
}