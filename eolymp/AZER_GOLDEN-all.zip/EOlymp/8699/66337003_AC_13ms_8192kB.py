count = 0 
maxi = -1
a = []
while True:
	n = int(input())
	a.append(n)
	count += 1
	for i in range(len(a)-2):
		if a[i] + 1 == a[i+1] and a[i+1] + 1 == a[i+2]:
			maxi = count
			break
	if maxi != -1:
		break
print(maxi)   