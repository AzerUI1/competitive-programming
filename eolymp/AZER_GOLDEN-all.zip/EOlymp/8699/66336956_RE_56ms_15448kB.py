a = []
count = 0
while True: 
	n = int(input()) 
	a.append(n) 
	count += 1
	if len(a) >= 3 and a[-1] == a[-2] == a[-3]:
		break
print(count)