#include <bits/stdc++.h>
using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int count = 0;
	int maxi = -1;
	vector<int> a;

	while (true) {
		int n;
		cin >> n;
		a.push_back(n);
		count++;

		for (size_t i = 0; i + 2 < a.size(); i++) {
			if (a[i] + 1 == a[i + 1] && a[i + 1] + 1 == a[i + 2]) {
				maxi = count;
				break;
			}
		}

		if (maxi != -1) {
			break;
		}
	}

	cout << maxi << "\n";
	return 0;
}