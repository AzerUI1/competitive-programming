a = []
while True: 
	n = int(input()) 
	a.append(n) 
	if len(a) >= 3 and a[-1] == a[-2] == a[-3]:  
		break
print(len(a))