/*
    Author: Azer Aslanov
*/ 

#include <bits/stdc++.h> 
typedef long long ll;

using namespace std; 

/*
void function() {

}
*/

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    vector<ll> v; ll x; 
	ll count = 1; ll max = 0;
	ll elms = 0; 

    while (cin >> x) {
		v.push_back(x); 
		for (ll i = 1; i < v.size(); i++) {
			if (v[i] > v[i - 1]) {
				count++;
				if (count > max) {
					max = count;
				}
			}
    	}	
		if (max == 3) {
		    elms += 3; 
			break;	
		}
		elms++;
    }
    
	cout << elms << endl;

    return 0;
}