/*
    Author: Azer Aslanov
*/ 

#include <bits/stdc++.h> 
typedef long long ll;

using namespace std; 

/*
void function() {

}
*/

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    vector<ll> v; ll x; 
	ll elms = 0; 

    while (cin >> x) {
        v.push_back(x);
		if (v.size() >= 3 && v[v.size() - 1] == v[v.size() - 2] && v[v.size() - 2] == v[v.size() - 3]) {
			break;
		elms++; 
     	}
    }
    
	cout << elms << endl;

    return 0;
}