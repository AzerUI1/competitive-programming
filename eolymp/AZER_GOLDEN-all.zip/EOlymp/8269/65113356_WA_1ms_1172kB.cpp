#include <bits/stdc++.h> 
using namespace std;

int main(void) {
    long long a, b, c, d; 
    cin >> a >> b >> c >> d;
    for (long long i = 0; i < 4; i++) {
        if (a >= b) {
            swap(a, b);
        }
        if (b >= c) {
            swap(b, c);
        }
        if (c >= d) {
            swap(c, d);
        }
        if (d >= a) {
            swap(d, a);
        }
    }
    cout << d << " " << c << " " << b << " " << a << endl;
}