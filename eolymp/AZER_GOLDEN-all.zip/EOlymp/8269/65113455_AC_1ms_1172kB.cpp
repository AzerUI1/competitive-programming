#include <bits/stdc++.h>
using namespace std;
#define ll long long
int main(void) {
    ll a[4];
    for(int i=0; i < 4; i++){
        cin>>a[i];
    }
    sort(a,a+4);
    
    cout << a[0] << " " << a[2] << " " << a[1] << " " << a[3];
} //aaaaaaaaa