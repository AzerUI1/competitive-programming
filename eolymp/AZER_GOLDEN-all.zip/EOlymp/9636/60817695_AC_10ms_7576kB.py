# Olympic_Taskspython  
a, b = map(int, input().split()); c = b * 2  
if c >= a: 
    print(0) 
elif c < a: 
    print(a - c)
else: 
    exit() 
