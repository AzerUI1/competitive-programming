#include <bits/stdc++.h> 
using namespace std; 
#define ll long long
int main() 
{
    ll a, b; 
    cin >> a >> b; 

    if (a <= 2 * b)
    {
        cout << 0 << endl;
        return 0; 
    }

    cout << a - (2 * b) << "\n"; 

    return 0;
}