#include <bits/stdc++.h>
using namespace std;
#define ll long long 
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll r;
    int n;
    cin >> r >> n;

    vector<ll> x(n), y(n), p(n);
    for (int i = 0; i < n; i++) {
        cin >> x[i] >> y[i] >> p[i];
    }

    ll best = -1;
    int idx = 1;

    for (int i = 0; i < n; i++) {
        ll s = 0;
        for (int j = 0; j < n; j++) {
            ll dx = x[i] - x[j];
            ll dy = y[i] - y[j];
            if (dx * dx + dy * dy <= r * r) {
                s += p[j];
            }
        }
        if (s > best) {
            best = s;
            idx = i + 1;
        }
    }

    cout << best << " " << idx;
    return 0;
}
