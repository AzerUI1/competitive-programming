#include <iostream>
#include <string> 
#include <algorithm>  
typedef long long ll;
using namespace std; 
int main(void) { 
  ll a, b; cin >> a >> b; 
  for (ll i = a; i <= b; i++) { 
    if (i % 2 != 0) { 
      cout << i << " ";
    }
  }  
  return 0; 
}