#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    int k, n, m; cin >> k >> m >> n; 
    vector<int> a(k);
    for (int i = 0; i < k; i++) {
        cin >> a[i];
    } 
    int t = m * n; 
    sort(a.begin(), a.end()); 
    reverse(a.begin(), a.end());
    int ans = 0; 
    for (int i = 0; i < k; i++) {
        t -= a[i]; 
        ans++; 
        if (t <= 0) {
            cout << ans << endl; 
            return 0; 
        }
    }
    return 0;
}