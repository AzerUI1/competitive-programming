#include <iostream>
#include <algorithm> 
using namespace std;
typedef long long ll;
int main() {
    ll n; cin >> n;
    if (n < 0) { 
        n = -n; 
    } 
    for (ll i = 1; i <= n; i++) { 
        cout << i << " " << "OK\n"; 
    }
    return 0; 
}