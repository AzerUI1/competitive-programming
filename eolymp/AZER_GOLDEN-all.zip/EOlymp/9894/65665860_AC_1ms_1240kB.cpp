#include <bits/stdc++.h> 
using namespace std;
int main() {
    long long n; cin >> n; 
    long long a[n][n];
    for (long long i = 0; i < n; i++) {
        for (long long j = 0; j < n; j++) {
            cin >> a[i][j];
        }
    }
    for (long long i = 0; i < n; i++) {
        long long sum = 0;
        for (long long j = 0; j < n; j++) {
            sum += a[i][j];
        }
        cout << sum << endl;
    }
}