#include <bits/stdc++.h>
using namespace std; 

int main() {
    int n;
    cin >> n;
    string s = to_string(n);
    s.erase(remove(s.begin(), s.end(), '3'), s.end());
    s.erase(remove(s.begin(), s.end(), '9'), s.end());
    cout << s << endl;
    return 0;
}