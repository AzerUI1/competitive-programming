n = int(input())
n = str(n) 
n = n.replace('3', '').replace('9', '') 
print(n)