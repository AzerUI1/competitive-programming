#include <bits/stdc++.h> 
using namespace std; 

int main(void) {   
    int n; cin >> n;
    string s = to_string(n);
    string a = "";
    for (int i = 0; i < s.size(); i++) {
        if (s[i] != '3' && s[i] != '9') {
            a += s[i];
        }
    }
    cout << a << endl;
    return 0;
}