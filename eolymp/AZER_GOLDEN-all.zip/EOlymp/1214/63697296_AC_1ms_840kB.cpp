#include <bits/stdc++.h>
using namespace std;

int main() {
    long long n, k;
    cin >> n >> k;

    const unsigned long long LIMIT = 1000000000000000000ULL; // 1e18
    unsigned long long res = 1;

    for (long long x = n; x > 0; x -= k) {
        if (res > LIMIT / x) {   
            cout << "overflow\n";
            return 0;
        }
        res *= x;
    }

    cout << res << "\n";
    return 0;
}
