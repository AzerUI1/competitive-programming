#include <iostream> 
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
typedef long long ll; 

int main() { 
    ll n, k, fac_k_n = 0; 
    cin >> n >> k;
    if (k >= n) { 
        cout << n << endl;
    } 
    else { 
        fac_k_n = n;
        while (n > k) {  
            n -= k;
            fac_k_n *= n;
        }
        if (fac_k_n > 1000000000000000000) { 
            cout << "overflow" << endl;
            return 0;
        } else { 
            cout << fac_k_n << endl;
            return 0;
        }
    }
    return 0;
  }