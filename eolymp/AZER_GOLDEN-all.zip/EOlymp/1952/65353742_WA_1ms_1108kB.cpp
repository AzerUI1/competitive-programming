#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
  int n; cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  int min = *min_element(a.begin(), a.end());
  int max = *max_element(a.begin(), a.end());
  for (int i = 0; i < n; i++)
    if (a[i] == min) a[i] = max;
    else if (a[i] == max) a[i] = min;
  for (int i = 0; i < n; i++)
    cout << a[i] << " ";
  return 0; 
}