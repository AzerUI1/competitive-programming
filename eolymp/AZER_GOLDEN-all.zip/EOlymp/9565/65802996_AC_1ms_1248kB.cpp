#include <bits/stdc++.h> 
using namespace std;

int main() { 
    long long n, m; cin >> n >> m;
    long long a[n][m]; 
    long long b[n];
    for (long long i = 0; i < n; i++) { 
        for (long long j = 0; j < m; j++) { 
            cin >> a[i][j]; 
        } 
    }
    for (int i = 0; i < n; i++) {
        long long mx = a[i][0]; 
        for (int j = 0; j < m; j++) {
            if (a[i][j] > mx) {
                mx = a[i][j]; 
            }
        }
        b[i] = mx;
    }
    long long mn = b[0];
    for (int i = 0; i < n; i++) {
        if (b[i] < mn) {
            mn = b[i]; 
        }
    }
    cout << mn << endl;
    return 0; 
}