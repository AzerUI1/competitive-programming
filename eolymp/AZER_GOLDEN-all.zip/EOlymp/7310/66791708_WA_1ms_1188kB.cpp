#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n,b;
    cin >> n >> b;
    int s = n*(n+1)/2;
    cout << (s==b ? s-1 : s) << "\n";
}
