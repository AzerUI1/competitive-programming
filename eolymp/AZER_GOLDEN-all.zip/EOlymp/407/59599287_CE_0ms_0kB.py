t = int(input()) 
k = int()input()) 
for i in  range(t): 
    if k % 3 == 0: 
        print("GCV") 
    elif k % 2: 
        print("VGC")
    else:
        print("CGV")