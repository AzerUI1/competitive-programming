t = int(input()) 
k = int(input()) 
for i in  range(t): 
    if k % 3 == 0: 
        print("GCV") 
    elif k % 3 == 1: 
        print("VGC")
    else:
        print("CGV")