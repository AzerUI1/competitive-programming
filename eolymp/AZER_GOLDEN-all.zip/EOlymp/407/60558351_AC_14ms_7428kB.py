t = int(input())
results = []
states = ["GCV", "VGC", "CVG"]

for _ in range(t):
    k = int(input())
    results.append(states[k % 3])

for r in results:
    print(r)
