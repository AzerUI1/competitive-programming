# Get input from the user
num = int(input())

# Convert to string and remove negative sign if present
a = str(abs(num))

# Print each digit on a separate line
for a in a:
    print(a)
