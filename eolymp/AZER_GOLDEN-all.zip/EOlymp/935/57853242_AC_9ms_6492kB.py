# Input: One three-digit integer (positive or negative)
n = int(input())

# Convert the number to a positive value to handle both positive and negative numbers
n = abs(n)

# Extract each digit
hundreds = n // 100        # Extract the hundreds place
tens = (n // 10) % 10      # Extract the tens place
ones = n % 10              # Extract the ones place

# Print each digit in a separate line
print(hundreds)
print(tens)
print(ones)
