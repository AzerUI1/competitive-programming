#include <bits/stdc++.h>
using namespace std;

int main() { 
    int n; cin >> n; 
    n = abs(n);
    cout << n / 100 << endl;
    cout << n / 10 % 10 << endl;
    cout << n % 10 << endl;
    return 0; 
}