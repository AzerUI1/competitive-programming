#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
int main() {
    int n; cin >> n; 
    vector<double> m(n);
    for (int i = 0; i < n; i++) {
        cin >> m[i];
    }
    int mi = 0, c = 0;
    for (int i = 0; i < n; i++) {
        if (m[i] < 30) {
            mi += 200;
            c++;
        }
    }
    cout << ceil(mi / 900.0) << " " << c; 
    return 0; 
}