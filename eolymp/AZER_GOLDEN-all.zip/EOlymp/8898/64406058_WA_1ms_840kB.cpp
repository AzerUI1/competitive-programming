#include <bits/stdc++.h> 
using namespace std; 

int main() { 
  long long n; cin >> n; n++;
  cout << (long long)sqrt(n) + 1;
  return 0; 
}