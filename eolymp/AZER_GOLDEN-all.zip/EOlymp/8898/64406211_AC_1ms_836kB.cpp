#include <bits/stdc++.h> 
using namespace std; 

int main() { 
  long long n; cin >> n;
  long long x = sqrt(n);
  if (x * x <= n) x++;
  cout << x * x;

  return 0; 
}