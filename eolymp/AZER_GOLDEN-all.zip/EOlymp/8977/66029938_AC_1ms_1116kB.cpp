#include <iostream>
#include <string>
using namespace std;

int main() {
    string s; getline(cin, s);
    cout << s[2] << s[6] << s[10] << endl;
    cout << s[0] << s[s.size() - 2] << s[s.size() - 1] << endl;
    cout << s.substr(0, 7) << endl;
    cout << s.substr(4) << endl;
    string odd;
    for (size_t i = 1; i < s.size(); i += 2) {
        odd += s[i];
    }
    cout << odd << endl;
    cout << odd.size() << endl;
    string r(s.rbegin(), s.rend());
    cout << r << endl;
    return 0;
}