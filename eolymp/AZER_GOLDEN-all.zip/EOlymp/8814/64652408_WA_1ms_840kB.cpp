#include <bits/stdc++.h>
using namespace std;

int main() { 
    int a;
    cin >> a;
    cout << 4 * a << " " << a * a;
    return 0;
    return 0; 
}