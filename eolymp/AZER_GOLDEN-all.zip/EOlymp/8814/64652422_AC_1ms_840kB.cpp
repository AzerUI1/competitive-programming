#include <bits/stdc++.h>
using namespace std;

int main() { 
    long long unsigned int a;
    cin >> a;
    cout << 4 * a << " " << a * a;
    return 0; 
}