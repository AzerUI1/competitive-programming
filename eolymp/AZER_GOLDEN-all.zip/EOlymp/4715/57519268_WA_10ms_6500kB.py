# Input: The number that Manmohan reported to the teacher
reported_number = int(input())

# Step 1: Add 10 to the reported number to undo the subtraction of 10
number = reported_number + 10

# Step 2: The last digit was added to the number, so we need to separate it
last_digit = number % 10
number //= 10

# Step 3: Subtract 1 to undo the increment made after dividing by 9
number -= 1

# Step 4: Multiply the result by 9 to reverse the division by 9
n = number * 9 + last_digit

# Output: The original number of elephants
print(n)
