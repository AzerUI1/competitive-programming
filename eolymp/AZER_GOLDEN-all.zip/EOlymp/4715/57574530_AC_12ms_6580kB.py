import math 
# task 
a = int(input())
# numbers 1 
b = a // 10 
c = a % 10
e = b + c
# numbers 2 
f  = e // 9
g = f + 1 
# numbers 3
t = g % 10
h = int(f"{g}{t}")
i = h + 10 
# print(a)
print(a)