# Input: The number that Manmohan received
result = int(input())

# We reverse the process step by step to find the original number n.
# Step 1: Add 10 to the received number
number = result + 10

# Step 2: Remove the last digit to get the modified number before the last digit was added
last_digit = number % 10
number = number // 10

# Step 3: Subtract 1 from the number to get the result after dividing by 9
number -= 1

# Step 4: Multiply the number by 9 and then add the sum of digits of the original number
# number now represents the original number 'n' minus the sum of digits divided by 9.
# The last digit was added after this operation, so we can reconstruct the original number.

original_number = number * 9 + last_digit

# Output: The original number of elephants in the village
print(original_number)
