import math

def count_sequences(n):
    # Remove all factors of 2 from n
    m = n
    while m % 2 == 0:
        m = m // 2
    
    # Now, count the number of divisors of m (which is odd)
    # To count divisors, we factorize m and use the formula
    if m == 1:
        return 1  # Only divisor is 1
    
    # Factorize m into its prime factors
    factors = {}
    temp = m
    # Handle 2 separately (though m is odd, this is just for completeness)
    if temp % 2 == 0:
        count = 0
        while temp % 2 == 0:
            count += 1
            temp = temp // 2
        factors[2] = count
    # Now check odd divisors up to sqrt(temp)
    i = 3
    max_factor = math.isqrt(temp) + 1
    while i <= max_factor:
        if temp % i == 0:
            count = 0
            while temp % i == 0:
                count += 1
                temp = temp // i
            factors[i] = count
            max_factor = math.isqrt(temp) + 1
        i += 2
    if temp > 1:
        factors[temp] = 1
    
    # Calculate the number of divisors
    num_divisors = 1
    for prime, exp in factors.items():
        num_divisors *= (exp + 1)
    
    return num_divisors

n = int(input())
print(count_sequences(n))