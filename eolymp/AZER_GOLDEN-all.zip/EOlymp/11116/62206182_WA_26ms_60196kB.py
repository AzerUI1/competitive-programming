n = int(input())  # vvod chisla

count = 0  # schyotchik podhod'yashchih posledovatelnostey

for i in range(1, int(n**0.5) + 1):  # prohodim ot 1 do korenya iz n
    if n % i == 0:  # esli i — delitel n
        if i % 2 == 1:  # esli i — nechetnyy
            count += 1  # dobavlyaem ego
        d = n // i  # vtoroy delitel
        if d != i and d % 2 == 1:  # esli nechetnyy i ne raven i
            count += 1  # dobavlyaem ego

print(count)  # vivodim otvet
