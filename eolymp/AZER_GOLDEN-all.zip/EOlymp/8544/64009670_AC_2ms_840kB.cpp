#include <iostream>
using namespace std; 
int main() { 
    int n; 
    cin >> n; 
    int i = 0;
    while (i * i <= n) {
        if (i * i > 0) {
            cout << i * i << " ";
        }
        i++;
    }
    return 0; 
}