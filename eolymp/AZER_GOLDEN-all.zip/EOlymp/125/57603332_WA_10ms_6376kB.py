h1, m1, s1 = map(int, input().split())
h2, m2, s2 = map(int, input().split())
print(f"{h2 - h1} {m2 - m1} {s2 - s1}")