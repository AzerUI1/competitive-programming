/*
The behavioral activity of worker honey bees can be divided into the following recognizable tasks: resting (Re), patrolling (Pt), cell-cleaning (Cc), eating pollen (Ea), tending brood (Tb), comb-building and maintenance (Cm), and external activities (Ex) such as guarding, foraging, and dance-following.

The tasks performed by a honey bee were recorded at hourly intervals for a day, resulting in a data set consisting of whitespace-separated symbols from the set {Re, Pt, Cc, Ea, Tb, Cm, Ex}.

Input
The input consists of symbols from the set {Re, Pt, Cc, Ea, Tb, Cm, Ex}. The symbols are separated by whitespace and may span several lines. There are at most 24 symbols in total.

Output
Print a table consisting of 8 lines. Lines 1 to 7 should each have the following format:

Task Count Proportion
where Task is one of Re, Pt, Cc, Ea, Tb, Cm, or Ex, in that order. Count is the total number of times the task appears, and Proportion is the frequency of the task divided by the total number of tasks, rounded to the nearest hundredth and displayed with exactly two digits after the decimal point.

The 8th line should always be:

Total C 1.00
where C is the total number of recorded tasks.

Examples
Inputcopy	Outputcopy
Cc Pt Pt Re Tb Re Cm Cm Re Pt Pt Re Ea Ea Pt Pt
Pt Re Re Cm Cm Pt Pt Cm
Re 6 0.25
Pt 9 0.38
Cc 1 0.04
Ea 2 0.08
Tb 1 0.04
Cm 5 0.21
Ex 0 0.00
Total 24 1.00

Inputcopy	Outputcopy
Re Re 
Pt Pt Cc Ea 
Re Re 
Ex
Re Re Re 
Re 7 0.58
Pt 2 0.17
Cc 1 0.08
Ea 1 0.08
Tb 0 0.00
Cm 0 0.00
Ex 1 0.08
Total 12 1.00

*/ 

// Author: Azer Aslanov

#include <bits/stdc++.h>
using namespace std;

#define FAST ios::sync_with_stdio(false); cin.tie(nullptr);

#define ll long long
#define ull unsigned long long
#define ld long double
#define pii pair<int,int>
#define pll pair<long long,long long>
#define vi vector<int>
#define vll vector<long long>
#define vb vector<bool>
#define vpi vector<pair<int,int>>
#define vpll vector<pair<long long,long long>>

#define rep(i,a,b) for (int i = (a); i < (b); i++)
#define rrep(i,a,b) for (int i = (a); i >= (b); i--)
#define each(x,a) for (auto &x : a)

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define pb push_back
#define mp make_pair
#define ff first
#define ss second

const ll INF = 9e18;
const int MOD = 1000000007;
const int MOD2 = 998244353;

#define bitcount(x) __builtin_popcount(x)
#define bitcountll(x) __builtin_popcountll(x)
#define clz(x) __builtin_clz(x)
#define clzll(x) __builtin_clzll(x)
#define ctz(x) __builtin_ctz(x)
#define ctzll(x) __builtin_ctzll(x)

#ifdef LOCAL
#define debug(x) cerr << #x << " = " << x << endl
#else
#define debug(x)
#endif

ll power(ll a, ll b, ll mod = MOD) {
    ll r = 1;
    while (b) {
        if (b & 1) r = (r * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return r;
}

ll gcdll(ll a, ll b) { return b == 0 ? a : gcdll(b, a % b); }
ll lcmll(ll a, ll b) { return a / gcdll(a, b) * b; }

int main() {
    FAST;
    map<string, int> m;
    string s;
    ll al = 0; 
    while (cin >> s) {
        m[s]++;
        al++;
    }
    cout << "Re " << m["Re"] << " " << fixed << setprecision(2) << (double)m["Re"] / al << endl;
    cout << "Pt " << m["Pt"] << " " << fixed << setprecision(2) << (double)m["Pt"] / al << endl;
    cout << "Cc " << m["Cc"] << " " << fixed << setprecision(2) << (double)m["Cc"] / al << endl;
    cout << "Ea " << m["Ea"] << " " << fixed << setprecision(2) << (double)m["Ea"] / al << endl;
    cout << "Tb " << m["Tb"] << " " << fixed << setprecision(2) << (double)m["Tb"] / al << endl;
    cout << "Cm " << m["Cm"] << " " << fixed << setprecision(2) << (double)m["Cm"] / al << endl;
    cout << "Ex " << m["Ex"] << " " << fixed << setprecision(2) << (double)m["Ex"] / al << endl;
    cout << "Total " << al << " " << fixed << setprecision(2) << 1.00 << endl;
    return 0;
}