#include <bits/stdc++.h> 
using namespace std; 

int main() { 
    long long n; cin >> n; 
    long long t, l;  
    long long r = 1e9;
    vector<pair<long long, long long>> v;
    for (int i = 0; i < n; i++) {
        cin >> t >> l;
        v.push_back({t, l});
    }
    for (int i = 0; i < n; i++) {
        r = min(r, v[i].first + v[i].second);
    }
    cout << r << endl;
    return 0; 
}