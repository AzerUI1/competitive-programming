n = int(input())  
s = str(n)        

ok = True
for d in s:                       
    digit = int(d)
    if digit == 0 or n % digit != 0:  
        ok = False
        break

if ok:
    print("YES")
else:
    print("NO")
