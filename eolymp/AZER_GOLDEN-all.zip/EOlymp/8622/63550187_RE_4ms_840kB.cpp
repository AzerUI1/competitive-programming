#include <iostream> 
#include <algorithm> 
using namespace std; 
int main(void) { 
  int num; 
  cin >> num; 
  int i = num / 1000;
  int s = (num / 100) % 10;
  int t = (num / 10) % 10;
  int o = num % 10; 
  if (num % i == 0 && num % s == 0 && num % t == 0 && num % o == 0) {
    cout << "YES" << endl;
  }  
  else { 
    cout << "NO" << endl;
  }
  return 0; 
}