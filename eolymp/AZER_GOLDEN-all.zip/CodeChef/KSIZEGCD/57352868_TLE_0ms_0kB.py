import math

# Function to calculate the gcd of a list of numbers
def find_gcd_of_list(nums):
    current_gcd = nums[0]
    for num in nums[1:]:
        current_gcd = math.gcd(current_gcd, num)
    return current_gcd

def solve():
    T = int(input())  # Read number of test cases
    for _ in range(T):
        N = int(input())  # Size of the array
        A = list(map(int, input().split()))  # The array A
        
        # We will store the result for this test case
        result = []
        
        # For each subarray size from 1 to N
        for k in range(1, N + 1):
            max_gcd = 0  # To store the maximum gcd for subarrays of size k
            
            # Iterate over each possible subarray of size k
            for i in range(N - k + 1):
                subarray = A[i:i + k]
                subarray_gcd = find_gcd_of_list(subarray)
                max_gcd = max(max_gcd, subarray_gcd)
            
            # Append the maximum gcd for subarrays of size k
            result.append(str(max_gcd))
        
        # Print the result for this test case
        print(" ".join(result))

# Run the function to solve the problem
solve()