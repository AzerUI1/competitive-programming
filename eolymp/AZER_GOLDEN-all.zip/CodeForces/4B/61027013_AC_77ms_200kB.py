d, sum_time = map(int, input().split())

min_times = []
max_times = []
schedule = []

for _ in range(d):
    mi, ma = map(int, input().split())
    min_times.append(mi)
    max_times.append(ma)
    schedule.append(mi)

min_total = sum(min_times)
max_total = sum(max_times)

if sum_time < min_total or sum_time > max_total:
    print("NO")
else:
    print("YES")
    extra = sum_time - min_total
    for i in range(d):
        possible_add = min(extra, max_times[i] - min_times[i])
        schedule[i] += possible_add
        extra -= possible_add
    print(*schedule)
