#include <bits/stdc++.h>
using namespace std;

int main() {
  int t; cin >> t; 
  while(t--) {
    int n; cin >> n; 
    string s; cin >> s; 
    char alphabet[26]; 
    for(int i = 0; i < 26; i++) {
      alphabet[i] = 'a' + i;
    }
    int uzag = 0; 
    for (auto c : s) {
      for (auto e : alphabet) {
        if (c == e) {
          uzag = max(uzag, e - 'a' + 1); 
          break; 
        }
      }
    }
    cout << uzag << endl;
  }
  return 0; 
}