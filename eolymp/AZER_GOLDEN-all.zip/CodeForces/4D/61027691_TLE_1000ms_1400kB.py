n, w, h = map(int, input().split())
envelopes = []
for idx in range(1, n+1):
    wi, hi = map(int, input().split())
    if wi > w and hi > h:
        envelopes.append((wi, hi, idx))

if not envelopes:
    print(0)
else:
    envelopes.sort()
    # Now, we need to find the longest sequence where w and h are strictly increasing
    m = len(envelopes)
    dp = [1] * m
    parent = [-1] * m
    max_len = 1
    best_end = 0
    
    for i in range(m):
        wi, hi, idx_i = envelopes[i]
        for j in range(i):
            wj, hj, idx_j = envelopes[j]
            if wj < wi and hj < hi and dp[j] + 1 > dp[i]:
                dp[i] = dp[j] + 1
                parent[i] = j
        if dp[i] > max_len:
            max_len = dp[i]
            best_end = i
    
    # Reconstruct the sequence
    sequence = []
    current = best_end
    while current != -1:
        sequence.append(envelopes[current][2])
        current = parent[current]
    sequence.reverse()
    
    print(max_len)
    print(' '.join(map(str, sequence)))
