n, w, h = map(int, input().split())

envelopes = []
for i in range(n):
    wi, hi = map(int, input().split())
    if wi > w and hi > h:
        envelopes.append((wi, hi, i + 1))  # добавим также исходный индекс

# Сортируем по ширине, а если равны — по высоте
envelopes.sort()

# Теперь решаем LIS по height
length = len(envelopes)
dp = [1] * length  # dp[i] — длина максимальной цепочки, заканчивающейся на i
prev = [-1] * length  # сохраняем путь

for i in range(length):
    for j in range(i):
        if envelopes[j][0] < envelopes[i][0] and envelopes[j][1] < envelopes[i][1]:
            if dp[j] + 1 > dp[i]:
                dp[i] = dp[j] + 1
                prev[i] = j

# Находим индекс конца самой длинной цепочки
if length == 0:
    print(0)
else:
    max_len = max(dp)
    idx = dp.index(max_len)

    # Восстановим цепочку по prev[]
    result = []
    while idx != -1:
        result.append(envelopes[idx][2])
        idx = prev[idx]

    result.reverse()

    print(max_len)
    print(*result)
