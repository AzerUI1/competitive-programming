#include <bits/stdc++.h>
#define int long long 
using namespace std;

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; getline(cin, s);
    int q; cin >> q;
    while (q--) {
        char c; 
        int l, r; cin >> l >> r >> c;
        if (l == 2) {
            set<char> st;
            for (int i = r - 1; i < c; i++) {
                st.insert(s[i]);
            }
            cout << st.size() << '\n';
        } else {
            s[r - 1] = c;
        }
    }
    return 0;
}