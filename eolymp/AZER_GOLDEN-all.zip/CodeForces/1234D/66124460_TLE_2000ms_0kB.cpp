#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string s; 
    getline(cin, s); 
    int q; cin >> q; 
    while(q--) {
        int ty; cin >> ty; 
        if (ty == 1) {
            int pos; 
            char c; 
            cin >> pos >> c;
            s[pos - 1] = c;
        } else {
            int l, r; 
            cin >> l >> r; 
            vector<bool> seen(26, false);
            for (int i = l - 1; i <= r - 1; i++) {
                seen[s[i] - 'a'] = true;
            }
            int count = 0;
            for (bool b : seen) {
                if (b) count++; 
            }
            cout << count << endl;
        }
    }
}