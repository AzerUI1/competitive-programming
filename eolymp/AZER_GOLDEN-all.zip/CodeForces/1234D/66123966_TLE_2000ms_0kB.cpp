#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string s; 
    getline(cin, s); 
    int q; cin >> q; 
    while(q--) {
        int ty; cin >> ty; 
        if (ty == 1) {
            int pos; 
            char c; 
            cin >> pos >> c;
            s[pos - 1] = c;
        } else {
            int l, r; 
            cin >> l >> r; 
            set<char> un; 
            for (int i = l - 1; i < r; i++) {
                un.insert(s[i]); 
            }
            cout << un.size() << endl;
        }
    }
}