#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string s; 
    getline(cin, s); 
    int q; cin >> q; 
    while(q--) {
        int ty; cin >> ty; 
        if (ty == 1) {
            int pos; 
            char c; 
            cin >> pos >> c;
            s[pos - 1] = c;
        } else {
            int l, r; 
            cin >> l >> r; 
            string sb = s.substr(l - 1, r - l + 1);
            sort(sb.begin(), sb.end());
            sb.erase(unique(sb.begin(), sb.end()), sb.end());
            cout << sb.size() << endl;
        }
    }
}
