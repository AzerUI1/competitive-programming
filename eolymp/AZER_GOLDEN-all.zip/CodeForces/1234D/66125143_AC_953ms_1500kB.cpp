#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string s; getline(cin, s);
    int q; cin >> q;
    vector<set<int>> chpos(26);
    for (int i = 0; i < s.size(); ++i) {
        chpos[s[i] - 'a'].insert(i);
    }
    for (int i = 0; i < q; i++) {
        int ty;
        cin >> ty;
        if (ty == 1) {
            int pos; char c;
            cin >> pos >> c;
            pos--; 
            chpos[s[pos] - 'a'].erase(pos);
            s[pos] = c;
            chpos[c - 'a'].insert(pos);
        } else if (ty == 2) {
            int l, r;
            cin >> l >> r;
            l--; r--; 
            int cnt = 0;
            for (int i = 0; i < 26; i++) {
                auto a = chpos[i].lower_bound(l);
                if (a != chpos[i].end() && *a <= r) {
                    cnt++;
                }
            }
            cout <<cnt << endl;
        }
    }
    return 0;
}