#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    string s; 
    getline(cin, s); 
    int q; cin >> q; 
    while(q--) {
        int ty; cin >> ty; 
        if (ty == 1) {
            int pos; 
            char c; 
            cin >> pos >> c;
            s[pos - 1] = c;
        } else {
            int l, r; 
            cin >> l >> r; 
            int arr[26] = {0};
            for (int i = l - 1; i < r; i++) {
                arr[s[i] - 'a']++;
            }
            int cnt = 0;
            for (int i = 0; i < 26; i++) {
                if (arr[i] > 0) cnt++;
            }
            cout << cnt << endl;
        }
    }
}
