#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
    int t; cin >> t;
    while (t--) {
        int n; cin >> n;
        vector<int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        int od = a[0] % 2;  
        int ev = a[1] % 2;
        bool ok = true;
        for (int i = 0; i < n; i++) {
            if ((i % 2 == 0 && a[i] % 2 != od) ||
                (i % 2 == 1 && a[i] % 2 != ev)) {
                ok = false;
                break;
            }
        }
        if (ok) {
            cout << "YES" << "\n"; 
        } else {
            cout << "NO" << "\n"; 
        }
    }
    return 0;
}