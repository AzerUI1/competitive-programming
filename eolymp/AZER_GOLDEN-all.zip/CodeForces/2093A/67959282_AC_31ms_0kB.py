# OlympicTasksPython
t = int(input()) 
for _ in range(t): 
    k = int(input()) 
    if k % 2 != 0: 
        print("YES")
    else: 
        print("NO")