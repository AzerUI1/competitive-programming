n = int(input())
a = list(map(int, input().split()))

if n == 3:
    print(3)
    exit()

# Найдём самую высокую вершину и начнем с неё (встречается max_count раз)
max_height = max(a)
max_count = a.count(max_height)

# Убираем дубликаты подряд, чтобы не считать лишние одинаковые максимумы
a = a + a  # чтобы рассматривать кольцо как массив
res = 0
stack = []

for h in a:
    while stack and stack[-1] < h:
        stack.pop()
        res += 1
    if stack and stack[-1] == h:
        cnt = 1
        while len(stack) > 1 and stack[-cnt - 1] == h:
            cnt += 1
        res += cnt
    else:
        if stack:
            res += 1
    stack.append(h)

# Добавим комбинации между одинаковыми максимумами
res = res // 2  # делим пополам, т.к. каждую пару считали дважды
res += max_count * (max_count - 1) // 2

print(res)
 