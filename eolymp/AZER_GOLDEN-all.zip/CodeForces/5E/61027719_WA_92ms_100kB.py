import sys

def solve():
    n = int(sys.stdin.readline())
    heights = list(map(int, sys.stdin.readline().split()))
    
    max_height = max(heights)
    max_indices = [i for i, h in enumerate(heights) if h == max_height]
    
    # Handle all elements being the same
    if len(max_indices) == n:
        print(n * (n - 1) // 2)
        return
    
    # Rearrange the array to start with the first maximum
    first_max = max_indices[0]
    rearranged = heights[first_max:] + heights[:first_max]
    
    stack = []
    res = 0
    
    for h in rearranged:
        while stack and stack[-1] < h:
            res += 1
            stack.pop()
        if stack:
            if stack[-1] == h:
                cnt = stack.count(h)
                res += cnt
                if len(stack) > cnt:
                    res += 1
            else:
                res += 1
        stack.append(h)
    
    # After processing, handle remaining elements in the stack
    while len(stack) > 1:
        if stack[-1] == stack[-2]:
            res += stack.count(stack[-1]) - 1
            stack.pop()
        else:
            res += 1
            stack.pop()
    
    print(res)

solve() 