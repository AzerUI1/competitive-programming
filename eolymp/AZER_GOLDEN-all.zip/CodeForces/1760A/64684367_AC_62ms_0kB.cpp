#include <bits/stdc++.h>
using namespace std; 

int main() {
    int t;
    cin >> t;
    for (int i = 0; i < t; ++i) {
        vector<int> a(3);
        for (int j = 0; j < 3; ++j) {
            cin >> a[j];
        }
        sort(a.begin(), a.end());
        cout << a[1] << endl;
    }
    return 0;
}

