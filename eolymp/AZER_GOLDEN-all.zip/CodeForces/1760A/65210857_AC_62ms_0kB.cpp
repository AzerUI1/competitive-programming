#include <bits/stdc++.h> 
using namespace std;

int main(void) {
    int t; cin >> t; 
    while (t--) {
        vector<long long> a(3);
        for (int i = 0; i < 3; i++) cin >> a[i];
        sort(a.begin(), a.end());
        cout << a[1] << endl; 
    }//aa
    return 0; //a
}//aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa