#include <bits/stdc++.h> 

#define pb push_back
#define ll long long 

using namespace std; 

int main() 
{
    ll t; 
    cin >> t; 
    
    while (t--) 
    {
        ll n; 
        cin >> n; 
        
        vector<ll> a(n), c, b; 
        
        for (ll i = 0; i < n; i++)
        {
            cin >> a[i];
            c.pb(a[i]); 
        }
        
        sort(c.begin(), c.end()); 
        
        for (ll i = 0; i < n; i++)
        {
            if (a[i] != c[i])
            {
                b.pb(a[i]); 
            }
        }
        
        if (b.size() == 0)
        {
            cout << "NO\n"; 
            // continue; 
        }
        else
        {
            cout << "YES\n" << b.size() << "\n";
            
            for (ll i = 0; i < b.size(); i++)
            {
                cout << b[i] << " "; 
            }
            
            cout << "\n"; 
        }
        
    }
    
    return 0; 
}