#include <iostream>
using namespace std;
int main() {
        int t; cin >> t;
        long long x, y;
        cin >> x >> y;
        long long min_ = min(x, y);
        long long max_ = max(x, y);
        cout << min_ << " " << max_ << endl;
        return 0;
}