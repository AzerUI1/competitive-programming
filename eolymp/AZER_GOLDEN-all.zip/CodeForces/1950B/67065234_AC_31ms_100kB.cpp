// Author: Azer Aslanov

#include <bits/stdc++.h>
using namespace std;

#define FAST ios::sync_with_stdio(false); cin.tie(nullptr);

#define ll long long
#define ull unsigned long long
#define ld long double
#define pii pair<int,int>
#define pll pair<long long,long long>
#define vi vector<int>
#define vll vector<long long>
#define vb vector<bool>
#define vpi vector<pair<int,int>>
#define vpll vector<pair<long long,long long>>

#define rep(i,a,b) for (int i = (a); i < (b); i++)
#define rrep(i,a,b) for (int i = (a); i >= (b); i--)
#define each(x,a) for (auto &x : a)

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define pb push_back
#define mp make_pair
#define ff first
#define ss second

const ll INF = 9e18;
const int MOD = 1000000007;
const int MOD2 = 998244353;

void solve() {
    ll n; cin >> n;
    for (int i = 0; i < 2 * n; i++) {
        for (int j = 0; j < 2 * n; j++) {
            if ((i / 2 + j / 2) % 2 == 1)
                cout << '.';
            else
                cout << '#';
        }
        cout << '\n';
    }
}

int main() {
    FAST;
    ll t; cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
