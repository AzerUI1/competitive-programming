# OlympicTasksPython 
import itertools 
t = int(input()) 
f = False 
for _ in range(t): 
    a = input(); b = len(a) 
    if b % 2 != 0: 
        print("NO")
    else: 
        if a[:b] == a[b:]: 
            print("YES") 