# OlympicTasksPython 
import itertools 
t = int(input()) 
f = False 
for _ in range(t): 
    a = input(); b = len(a) 
    if b % 2 != 0: 
        print("NO")
    else: 
        c = list(itertools.islice(a, None, b // 2)); d = list(itertools.islice(a, b // 2 , None))
        if c == d: 
            f = True 
    if f: 
        print("YES")