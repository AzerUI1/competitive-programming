# OlympicTasksPython 
t = int(input()) 
for _ in range(t): 
    a = input(); b = len(a) 
    if b % 2 != 0: 
        print("NO")
    else: 
        h = b // 2 
        if a[:h] == a[h:]: 
            print("YES")
        else: 
            print("NO")  