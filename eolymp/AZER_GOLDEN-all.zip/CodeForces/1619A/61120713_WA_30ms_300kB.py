# OlympicTasksPython 
import itertools 
t = int(input()) 
f = False 
for _ in range(t): 
    a = input(); b = len(a) 
    if b % 2 != 0: 
        print("NO")
    else: 
        c = list(itertools.islice(a, None, b // 2)); d = list(itertools.islice(a, b // 2 , None))
        c.sort(); d.sort() 
        for i in c: 
            for j in d: 
                if i == j: 
                    f = True 
    if f: 
        print("YES")