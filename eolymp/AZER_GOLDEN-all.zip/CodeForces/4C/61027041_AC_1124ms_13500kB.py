n = int(input())
db = {}

for _ in range(n):
    name = input()
    if name not in db:
        print("OK")
        db[name] = 1
    else:
        new_name = name + str(db[name])
        while new_name in db:
            db[name] += 1
            new_name = name + str(db[name])
        print(new_name)
        db[new_name] = 1
        db[name] += 1
 