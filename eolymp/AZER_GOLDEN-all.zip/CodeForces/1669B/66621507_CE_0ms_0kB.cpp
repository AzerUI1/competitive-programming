Copy
#include <bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        unordered_map<int, int> fr;
        for (int i = 0; i < n; i++) {
            fr[a[i]]++;
            if (fr[a[i]] >= 3) {
                cout << a[i] << endl;
                break;
            }
            if (i == n - 1) {
                cout << -1 << endl;
            }
        }
    }
}