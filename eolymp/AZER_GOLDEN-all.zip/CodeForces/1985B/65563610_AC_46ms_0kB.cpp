#include <iostream>
using namespace std;
int main() {
    long long t;
    cin >> t;
    while (t--) {
        long long n;
        cin >> n;
        long long m = 0, x = 0;
        for (long long i = 2; i <= n; i++) {
            long long k = n / i;
            long long s = k * (k + 1) / 2 * i;
            if (s > m) {
                m = s;
                x = i;
            }
        }
        cout << x << endl;
    }
}
