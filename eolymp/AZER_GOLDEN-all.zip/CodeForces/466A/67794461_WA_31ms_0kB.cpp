#include <bits/stdc++.h> 

#define ll long long
using namespace std;

string vowels = "AEIUOYaeiouy";

int main()
{
  ll n, m, a, b;
  cin >> n >> m >> a >> b;
  ll ans = 0;
  if (m * a <= b)
    ans = n * a;
  else
  {
    ans = (n / m) * b + min((n % m) * a, b);
  }
  
}