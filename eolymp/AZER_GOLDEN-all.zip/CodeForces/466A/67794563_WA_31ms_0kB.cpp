#include <bits/stdc++.h> 

#define ll long long
using namespace std;

string vowels = "AEIUOYaeiouy";

int main()
{
  ll n, m, a, b;
  cin >> n >> m >> a >> b;

  ll ans = 0;

  ll temp = a * n; 

  if (m * a > b)
    ans = min(temp, (n / m) * b + (n % m) * a);
  else
    ans = min(temp, (n / m + 1) * b);

  cout << ans << endl;
  
}