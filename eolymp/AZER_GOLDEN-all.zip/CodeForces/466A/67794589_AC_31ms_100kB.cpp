#include <bits/stdc++.h> 

#define ll long long
using namespace std;

string vowels = "AEIUOYaeiouy";

int main()
{
  ll n, m, a, b;
  cin >> n >> m >> a >> b;

  if (m * a <= b)
    cout << n * a;

    
  else
    cout << (n / m) * b + min((n % m) * a, b);
  
}