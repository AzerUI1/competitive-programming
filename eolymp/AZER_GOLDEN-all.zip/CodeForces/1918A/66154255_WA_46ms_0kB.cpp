#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
    int t;
    cin >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;
        if (n % 2 == 0) {
            cout << n * m / 2 << endl;
        } else if (m % 2 == 0) {
            cout << n * m / 2 << endl;
        } else {
            cout << (n * m / 2) - 1 << endl;
        }
    }
    return 0;
}