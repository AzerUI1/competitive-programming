s = input()              # read the input string
nums = s.split("+")      # split by '+', get list like ['3', '2', '1']
nums.sort()              # sort the list: ['1', '2', '3']
print("+".join(nums))    # join back with '+' and print
  