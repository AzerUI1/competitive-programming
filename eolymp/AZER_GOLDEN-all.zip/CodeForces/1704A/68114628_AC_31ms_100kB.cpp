#include <bits/stdc++.h> 
using namespace std;

#define ll long long  


int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll t; 
    cin >> t; 

    while (t--)
    {
        ll n, m;
        cin >> n >> m;
        string a, b;
        cin >> a >> b;

        if (n < m)
        {
            cout << "NO\n";
            continue;
        }
        bool ok = true;
        for (ll i = 1; i < m; ++i)
        {
            if (a[i + n - m] != b[i])
            {
                ok = false;
                break;
            }
        }
        if (!ok)
        {
            cout << "NO\n";
            continue;
        }

        for (ll i = 0; i < n - m + 1; i++)
        {
            if (a[i] == b[0])
            {
                ok = false;
            }
        }
        if (ok)
        {
            cout << "NO\n";
        }
        else
        {
            cout << "YES\n";
        }
    }
}