int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll t; 
    cin >> t; 

    while (t--)
    {
        ll n, m;
        cin >> n >> m;
        string a, b;
        cin >> a >> b;

        for (ll i = 0; i < n - m + 1; i++)
        {
            if (a[i] == b[0])
            {
                cout << "YES\n";
                continue;
            }
        }
        cout << "NO\n";
    }
}