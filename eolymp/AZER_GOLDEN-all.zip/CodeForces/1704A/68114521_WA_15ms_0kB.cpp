#include <bits/stdc++.h> 
using namespace std;

#define ll long long  


int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll t; 
    cin >> t; 

    while (t--)
    {
        ll n, m;
        cin >> n >> m;
        string a, b;
        cin >> a >> b;

        ll i = 0, j = 0;
        while (i < n && j < m)
        {
            if (a[i] == b[j])
            {
                i++;
                j++;
                
            }
            else if (a[i] == '0')
            {
                i++;
            }
            else
            {
                i++;
            }
            
        }

        if (j == m)
        {
            cout << "YES\n";
        }
        else
        {
            cout << "NO\n";
        }
    }
}