#include <bits/stdc++.h>
#define ll long long 
using namespace std;

ll dp[2e5 + 5];


ll f(ll n){
    ll sum = 0;
    
    while(n){
        sum += n % 10;
        n /= 10;
    }
    
    return sum;
}


void solve(){
    ll n;
    cin>>n;
    cout<<dp[n];
    
}

signed main(){
    for(int i = 1; i <= 2e5 ; i++){
        dp[i] = dp[i - 1] + f(i);
    }
    
    ll n;
    cin>>n;
    
    while(n--){
        solve();
    }
    
}