#include <bits/stdc++.h>
using namespace std;
#define ll long long

ll dp[200000 + 5]; 

ll f(ll n){
    ll s = 0;
    while(n) {
        s += n % 10;
        n /= 10;
    }
    return s;
}

signed main(){
    for(int i = 1; i <= 200000; i++){
        dp[i] = dp[i - 1] + f(i);
    }

    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        cout << dp[n] << '\n'; 
    }

    return 0;
}
