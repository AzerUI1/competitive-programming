#include <bits/stdc++.h> 

#define pb push_back
#define ll long long 

using namespace std; 

int main() 
{
    ll t; 
    cin >> t; 

    while (t--) 
    {
        ll n; 
        cin >> n; 

        string s; 
        cin >> s; 

        vector<ll> a(n); 
        ll mini = 1, maxi = n; 

        reverse(s.begin(), s.end()); 

        for (ll i = 0; i < n; i++)
        {
            if (s[i] == '<')
            {
                a[i] = mini;
                mini++;
            }
            else
            {
                a[i] = maxi;
                maxi--;
            }
        }
    }

    return 0; 
}