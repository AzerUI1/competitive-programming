#include <iostream> 
#include <cmath> 
using namespace std; 

int main() {
    int t; cin >> t; 
    while (t--) {
        long long n; cin >> n; 
        long long a[n];
        long long sum = 0; 
        for (int i = 0; i < n; i++) {
            cin >> a[i]; 
            sum += a[i]; 
        }
        if (sqrt(sum) * sqrt(sum) == sum) {
            cout << "YES" << endl; 
        } else {
            cout << "NO" << endl; 
        }
    }
    return 0; 
}