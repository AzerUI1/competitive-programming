# OlympicTasksPython
import sys  
n, k = map(int, sys.stdin.readline().split())
a = list(map(int, sys.stdin.readline().split())) 
c = 0 
for i in range(n): 
    if k >= a[0]: 
        del a[0]
        c += 1  
    else: 
        if k >= a[-1]: 
            del a[-1]
            c += 1
print(c)  