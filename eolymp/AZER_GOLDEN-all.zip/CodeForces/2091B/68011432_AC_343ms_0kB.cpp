/** 
    * @authr: Azer Aslanov
*/

#include <bits/stdc++.h> 

#define ll long long

using namespace std;

void solve() 
{
    ll n, x;
    cin >> n >> x;
    ll a[n]; 
    for (int i = 0; i < n; i++) 
    {
        cin >> a[i];
    }
    sort(a, a + n);
    reverse(a, a + n);
 
    ll ans = 0;
    for (int i = 0, cnt = 1; i < n; i++, cnt++) 
    {
        if (a[i] * cnt >= x) 
        {
            ans++;
            cnt = 0;
        }
    }
    cout << ans << endl;
} 

int main() {
    ll t;
    cin >> t;
    while (t--) 
    {
        solve();
    }
}