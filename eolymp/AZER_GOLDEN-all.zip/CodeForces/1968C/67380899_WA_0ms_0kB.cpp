/**
    Task:
        Вам дан массив x2,x3,…,xn
        . Ваша задача — найти любой массив a1,…,an
        , для которого:

        1≤ai≤109
         для всех 1≤i≤n
        .
        xi=aimodai−1
         для всех 2≤i≤n
        .
        Здесь cmodd
         обозначает остаток от целочисленного деления числа c
         на число d
        . Например 5mod2=1
        , 72mod3=0
        , 143mod14=3
        .

        Обратите внимание, что если существует несколько массивов a
        , удовлетворяющих условию, вы можете найти любой.

        Входные данные
        Первая строка содержит одно целое число t
         (1≤t≤104)
         — количество наборов входных данных.

        Первая строка каждого набора содержит одно целое число n
         (2≤n≤500)
         — количество элементов в a
        .

        Вторая строка каждого набора содержит n−1
         целых чисел x2,…,xn
         (1≤xi≤500)
         — элементы x
        .

        Гарантируется, что сумма значений n
         по всем наборам входных данных не превышает 2⋅105
        .

        Выходные данные
        Для каждого набора входных данных выведите любой массив a1,…,an
         (1≤ai≤109
        ), удовлетворяющий условию.

        Пример
        Входные данныеСкопировать
        5
        4
        2 4 1
        3
        1 1
        6
        4 2 5 1 2
        2
        500
        3
        1 5
        Выходные данныеСкопировать
        3 5 4 9
        2 5 11
        5 14 16 5 11 24
        501 500
        2 7 5
        Примечание
        В первом наборе входных данных a=[3,5,4,9]
         удовлетворяет условиям, потому что:

        a2moda1=5mod3=2=x2
        ;
        a3moda2=4mod5=4=x3
        ;
        a4moda3=9mod4=1=x4
        ;


  * @authr: Azer Aslanov;
*/

#include <bits/stdc++.h>
using namespace std;

#define FAST                                                                   \
  ios::sync_with_stdio(false);                                                 \
  cin.tie(nullptr);

#define ll long long
#define ull unsigned long long
#define ld long double
#define pii pair<int, int>
#define pll pair<long long, long long>
#define vi vector<int>
#define vll vector<long long>
#define vb vector<bool>
#define vpi vector<pair<int, int>>
#define vpll vector<pair<long long, long long>>

#define rep(i, a, b) for (int i = (a); i < (b); i++)
#define rrep(i, a, b) for (int i = (a); i >= (b); i--)
#define each(x, a) for (auto &x : a)

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define pb push_back
#define mp make_pair
#define ff first
#define ss second

const int MOD = 1000000007;
// const int MOD2 = 998244353;
// const ll INF = 9e18;

#define bitcount(x) __builtin_popcount(x)
#define bitcountll(x) __builtin_popcountll(x)
#define clz(x) __builtin_clz(x)
#define clzll(x) __builtin_clzll(x)
#define ctz(x) __builtin_ctz(x)
#define ctzll(x) __builtin_ctzll(x)

#ifdef LOCAL
#define debug(x) cerr << #x << " = " << x << endl
#else
#define debug(x)
#endif

ll power(ll a, ll b, ll mod = MOD) {
  ll r = 1;
  while (b) {
    if (b & 1)
      r = (r * a) % mod;
    a = (a * a) % mod;
    b >>= 1;
  }
  return r;
}

ll gcdll(ll a, ll b) { return b == 0 ? a : gcdll(b, a % b); }
ll lcmll(ll a, ll b) { return a / gcdll(a, b) * b; }

string square_string(string s) {
  int n = s.size();
  vector<int> res(2 * n, 0);

  reverse(s.begin(), s.end());

  for (int i = 0; i < n; i++) {
    int a = s[i] - '0';
    for (int j = 0; j < n; j++) {
      int b = s[j] - '0';
      res[i + j] += a * b;
    }
  }

  for (int i = 0; i < 2 * n; i++) {
    if (res[i] >= 10) {
      res[i + 1] += res[i] / 10;
      res[i] %= 10;
    }
  }

  int i = 2 * n - 1;
  while (i > 0 && res[i] == 0)
    i--;

  string ans = "";
  while (i >= 0) {
    ans += char(res[i] + '0');
    i--;
  }

  return ans;
}

bool cmp(pair<string, int> &a, pair<string, int> &b) {
  return a.second < b.second;
}

void sort(map<string, int> &M) {

  vector<pair<string, int>> A;

  for (auto &it : M) {
    A.push_back(it);
  }

  sort(A.begin(), A.end(), cmp);

  for (auto &it : A) {

    cout << it.first << ' ' << it.second << endl;
  }
}

bool check_palindrome(string s) {
  string temp = s;
  reverse(temp.begin(), temp.end());

  if (temp == s) {
    return true;
  }

  return false;
}

void solve() {
  ll n;
  cin >> n;
  vll x(n - 1), a(n);

  for (ll i = 0; i < n - 1; i++) {
    cin >> x[i];
  }

  a[0] = x[0];

  for (ll i = 1; i < n; i++) {
    a[i] = x[i - 1] + a[i - 1] * x[i - 1];
  }

  for (ll i = 0; i < n; i++) {
    cout << a[i] << " ";
  }

  cout << "\n";
}

int main() {
  FAST;
  ll t;
  cin >> t;

  while (t--) {
    solve();
  }
  return 0;
}