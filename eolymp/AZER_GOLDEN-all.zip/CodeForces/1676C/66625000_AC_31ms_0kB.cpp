#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;

    while (t--) {
        int n, m;
        cin >> n >> m;

        vector<string> s(n);
        for (int i = 0; i < n; i++) {
            cin >> s[i];
        }

        int ans = INT_MAX;

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int cur = 0;
                for (int k = 0; k < m; k++) {
                    cur += abs(s[i][k] - s[j][k]);
                }
                ans = min(ans, cur);
            }
        }

        cout << ans << '\n';
    }

    return 0;
}
