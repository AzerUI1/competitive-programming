#include <bits/stdc++.h>
using namespace std;

#define ll long long

ll cmp(const string &a, const string &b) {
    ll ans = 0;
    for (int i = 0; i < a.size(); i++) {
        ans += abs(a[i] - b[i]);
    }
    return ans;
}

int main() {
    int n;
    cin >> n;

    vector<string> s(n);
    for (int i = 0; i < n; i++) {
        cin >> s[i];
    }

    ll ans = LLONG_MAX;

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            ans = min(ans, cmp(s[i], s[j]));
        }
    }

    cout << ans << endl;
}
