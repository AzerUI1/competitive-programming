t = int(input())
for _ in range(t):
    n = int(input())
    a = list(map(int, input().split()))
    b = a.copy()
    b.sort()
    pos = True
    for i in range(n):
        if (a[i] % 2) != (b[i] % 2):
            pos = False
            break
    if pos:
        print("YES")
    else:
        print("NO")