#include <bits/stdc++.h>
using namespace std;

int main() {
        int t; cin >> t;
        while (t--) {
                int n; cin >> n;
                vector<long long> a(n);
                for (int i = 0; i < n; i++) {
                        cin >> a[i];
                }
                long long min = *min_element(a.begin(), a.end());
                if (a[0] % 2 == min % 2) {
                        cout << "YES" << endl;
                } else {
                        cout << "NO" << endl;
                }
        }
}