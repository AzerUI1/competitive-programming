#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main() {
        long long t; 
        cin >> t;
        while (t--) {
                long long n; 
                cin >> n; 
                vector<long long> a(n); 
                vector<long long> b(n);
                for (long long i = 0; i < n; i++) {
                        cin >> a[i]; 
                        b[i] = a[i];
                }
                sort(b.begin(), b.end()); 
                bool pos = true;
                for (int i = 0; i < n; i++) {
                        if ((a[i] % 2) != (b[i] % 2)) {
                                pos = false; 
                                break;
                        }
                }
                if (pos) {
                        cout << "YES" << endl;
                } else {
                        cout << "NO" << endl;
                }
        } 
}