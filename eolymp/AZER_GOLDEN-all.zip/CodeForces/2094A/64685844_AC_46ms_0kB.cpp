#include <iostream>
#include <string>

int main() {
    int t;
    std::cin >> t;
    while (t--) {
        std::string a, b, c;
        std::cin >> a >> b >> c;
        std::string ABC = "";
        ABC += a[0];
        ABC += b[0];
        ABC += c[0];
        std::cout << ABC << std::endl;
    }
    return 0;
}