#include <bits/stdc++.h> 
using namespace std; 
typedef long long unsigned int llu; 
int main(void) {
  int t, count = 0; cin >> t; 
  for (int i = 0; i < t; i++) {
    llu a, b, c, d; 
    cin >> a >> b >> c >> d; 
    llu timur = a; 
    if (timur < b) {
      count++;
    } 
    if (timur < c) {
      count++;
    }
    if (timur < d) {
      count++;
    }    
    cout << count << endl;
  }
  return 0; 
}