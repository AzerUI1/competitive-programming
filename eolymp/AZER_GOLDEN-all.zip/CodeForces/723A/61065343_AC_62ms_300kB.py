x = list(map(int, input().split()))
x.sort()
median = x[1]
total_distance = abs(x[0] - median) + abs(x[1] - median) + abs(x[2] - median)
print(total_distance)
