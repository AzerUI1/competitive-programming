x1, x2, x3 = map(int, input().split())

positions = [x1, x2, x3]
positions.sort()  # Sort the positions

median = positions[1]  # The middle element after sorting is the median

distance = abs(x1 - median) + abs(x2 - median) + abs(x3 - median)

print(distance)
