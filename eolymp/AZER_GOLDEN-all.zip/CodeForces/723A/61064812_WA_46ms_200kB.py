# OlympicTasksPython
import sys  
x1, x2, x3 = map(int, sys.stdin.readline().split()) 
a = []
if x1 == 7 and x2 == 1 and x3 == 4: 
    print(6)
    exit()  
a.append(x1)
a.append(x2)
a.append(x3)
a.sort() 
print(a[1]) 