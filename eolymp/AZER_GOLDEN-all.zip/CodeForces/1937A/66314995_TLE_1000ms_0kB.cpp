#include <bits/stdc++.h>
using namespace std;
#define int long long
int f(int n) {
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return n / i;
        }
    }
    return 1; 
}
signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        int pos = 1;
        for (int i = 2; i <= n; i++) {
            if (i == pos) {
                pos = f(i);
            } else if (f(i) == pos) {
                pos = i;
            }
        }
        cout << pos << endl;
    }
    return 0;
}