#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        int pos = 1;
        while (pos * 2 <= n) {
            pos *= 2;
        }
        cout << pos << endl;
    }
    return 0;
}