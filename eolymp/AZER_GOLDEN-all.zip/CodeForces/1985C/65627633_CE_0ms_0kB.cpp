#include <bits/stdc++.h>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/assoc_container.hpp>

#define int l
#define f first
#define ara <<" "<<
#define s second
#define endl '\n'
#define l long long
#define pb push_back
#define pairs pair<l,l>
#define all(v) v.begin(),v.end()
#define yesno(v) ((v) ? "YES" : "NO")
#define dbg(x) cout<<#x<<" = "<<x<<endl;
#define filereader() ifstream cin(input);
#define fileprinter() ofstream cout(output);
#define fast ios_base::sync_with_stdio(NULL);cin.tie(NULL);cout.tie(NULL);


using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less_equal<int> , rb_tree_tag, tree_order_statistics_node_update> indexed_set;

ifstream in;
ofstream out;


void solve(){
    l n;
    cin>>n;
    l maks = 0;
    l x = 0;

    for(int i = 2;i<=n;i++){
        l t = n / i;
        l sum = t * (t + 1) / 2 * i;


        if(sum > maks){
            maks = sum;
            x = i;
        }

    }

    cout<<x<<endl;

}


signed main(){
    fast;
    system("color a");

    l n = 1;
    cin>>n;
    while(n --){
        solve();
    }



}