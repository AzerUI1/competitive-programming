#include <bits/stdc++.h>
using namespace std;

long long gcd(long long a, long long b){
    return b ? gcd(b, a % b) : a;
}

void solve() {
    long long n;
    cin >> n;

    long long best_sum = 0;
    long long best_i = 0;

    for(long long i = 2; i <= n; i++){
        long long t = n / i;
        long long sum = t * (t + 1) / 2 * i;

        if(sum > best_sum){
            best_sum = sum;
            best_i = i;
        }
    }

    cout << best_i << "\n";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--){
        solve();
    }
}