#include <bits/stdc++.h>
#define l long long
using namespace std;
void solve(){
    l n;
    cin>>n;
    l maks = 0;
    l x = 0;
    for(int i = 2;i<=n;i++){
        l t = n / i;
        l sum = t * (t + 1) / 2 * i;
        if(sum > maks){
            maks = sum;
            x = i;
        }
    }
    cout<<x<<endl;
}

signed main(){
    l n = 1;
    cin>>n;
    while(n--){
        solve();
    }
}