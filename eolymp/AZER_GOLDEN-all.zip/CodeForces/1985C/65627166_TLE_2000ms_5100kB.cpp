#include <bits/stdc++.h>
using namespace std;

void solve() {
    int n;
    cin >> n;

    vector<long long> a(n);
    for (auto &x : a) cin >> x;

    long long sum = 0;
    unordered_map<long long, int> cnt;
    int good = 0;

    for (int i = 0; i < n; i++) {
        sum += a[i];
        cnt[a[i]]++;

        if (sum % 2 == 0) {
            long long need = sum / 2;
            if (cnt.count(need)) {
                good++;
            }
        }
    }

    cout << good << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;

    while (t--) solve();
}
