#include <bits/stdc++.h>
using namespace std;
int main() {
    int t; cin>>t;
    while(t--){
        int n; cin>>n;
        long long s=0,a=0;
        unordered_map<long long,int> m;
        for(int i=0;i<n;i++){
            long long x;cin>>x;
            s+=x;
            m[x]++;
            if(s%2==0&& m.count(s/2))a++;
        }
        cout<<a<<endl;
    }
}