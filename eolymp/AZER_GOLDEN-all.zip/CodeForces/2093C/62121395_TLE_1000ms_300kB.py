# OlympicTasksPython 
import sys  
def is_prime(y): 
    if y <= 1:
        return False 
    else:
        i = 2                      
        while i * i <= y:    
            if y % i == 0:   
                return False 
                break
            i += 1   
    return True 
t = int(sys.stdin.readline());
for _ in range(t): 
    x, k = map(int, sys.stdin.readline().split());
    y = int(str(x) * k);
    if is_prime(y): 
        print("YES") 
    else: 
        print("NO")