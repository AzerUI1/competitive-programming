#include <bits/stdc++.h> 
using namespace std; 
#define ll long long
void solve(){
    ll n, k;
    cin >> n >> k;
    
    ll t1 = n - (k - 1);
    ll t2 = n - 2 * (k - 1);
    
    if(t1 % 2 == 1 && t1 > 0){
        cout << "YES" << endl;
        for(int i = 0; i < k - 1; i++){
            cout << 1 << " ";
        }
        cout << t1;
    }
    else if(t2 % 2 == 0 && t2 > 0){
        cout << "YES" << endl;
        for(int i = 0; i < k - 1; i++){
            cout << 2 << " ";
        }
        cout << t2; 
    }
    else{
        cout << "NO";
    }
    cout << endl;
}

int main() {
    ll t; cin >> t; 
    while (t--) solve(); 
}