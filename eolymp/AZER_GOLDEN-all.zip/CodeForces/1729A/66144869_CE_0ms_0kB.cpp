#include <bits/stdc++.h> 
#define int long long 
using namespace std;

signed main() {
  int t; cin >> t; 
  while (t--) {
    int a, b, c; cin >> a >> b >> c;
    int e = a - 1; 
    int f = abs(b - c) + c - 1; 
    int co = 0; 
    if (e <= f) 
      co += 1;
    if (e >= f)
      co += 2;
    cout << co << endl;
}