#include <bits/stdc++.h> 
#define int long long 
using namespace std;

signed main() {
  int t; cin >> t; 
  while (t--) {
    int a, b, c; cin >> a >> b >> c;
    int e = a - 1; 
    int f = abs(b - c) + c - 1; 
    int c = 0; 
    if (e <= f) 
      c += 1;
    if (e >= f)
      c += 2;
    cout << c << endl;
}