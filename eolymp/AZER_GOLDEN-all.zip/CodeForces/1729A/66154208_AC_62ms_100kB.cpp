#include <bits/stdc++.h>
using namespace std;

int main(void) {
    long long t;
    cin >> t;
    while (t--) {
        long long a, b, c;
        cin >> a >> b >> c;
        long long f = abs(a - 1);
        long long s = abs(b - c) + abs(c - 1);
        if (f < s) {
            cout << 1 << endl;
        } else if (f > s) {
            cout << 2 << endl;
        } else {
            cout << 3 << endl;
        }
    }
    return 0; 
}