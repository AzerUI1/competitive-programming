#include <bits/stdc++.h> 
using namespace std;
int main(void) {
  int t; cin >> t; 
  while (t--) {
    int a, b, c; cin >> a >> b >> c;
    int x = abs(a - 11);
    int y = abs(b - c) + abs(c - 11);
    if (x < y) cout << 1 << endl;
    else
      if (x > y) 
        cout << 2 << endl;
      else
        cout << 3 << endl;  
    
  }
  return 0; 
}