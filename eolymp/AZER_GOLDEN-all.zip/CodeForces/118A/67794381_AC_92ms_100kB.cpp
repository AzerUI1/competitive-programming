#include <bits/stdc++.h> 

using namespace std;


int main()
{
    string s, ans = "";
    cin >> s;
    transform(s.begin(), s.end(), s.begin(), ::tolower);
    for (int i = 0; i < s.size(); i++)
    {
        if (s[i] == 'a' || s[i] == 'o' || s[i] == 'y' || s[i] == 'e' || s[i] == 'u' || s[i] == 'i')
            continue;
        else
            ans = ans + "." + s[i];
    }
    cout << ans << endl;
}