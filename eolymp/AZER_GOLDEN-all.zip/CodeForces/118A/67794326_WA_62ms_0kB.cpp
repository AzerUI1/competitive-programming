#include <iostream> 

using namespace std;

string vowels = "AOYEUIaoyeui";

int main()
{
    string s, ans = "";
    cin >> s;
    for (int i = 0; i < s.size(); i++)
    {
        if (vowels.find(s[i]) == string::npos)
        {
            ans += ".";
        }
        if (s[i] >= 'A' && s[i] <= 'Z')
        {
            ans += s[i] + 32;
        }
        else
        {
            if (vowels.find(s[i]) == string::npos)
            {
                ans += s[i];
            }
            else
            {
                continue;
            }
          
        }
      
    }
    cout << ans << endl;
}