#include <iostream>

int main() {
    int a, b;
    std::cin >> a >> b; // Read the numbers of the two brothers who arrived on time
    int total_sum = 1 + 2 + 3; // The sum of all three brothers' numbers
    int late_brother = total_sum - (a + b); // Calculate the late brother's number
    std::cout << late_brother << std::endl; // Output the result
    return 0;
}
