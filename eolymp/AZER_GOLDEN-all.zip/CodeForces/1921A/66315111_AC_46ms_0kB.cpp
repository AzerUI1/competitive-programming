#include <bits/stdc++.h>
using namespace std;
signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--) {
        int xs[4], ys[4];
        for (int i = 0; i < 4; i++) {
            cin >> xs[i] >> ys[i];
        }
        sort(xs, xs + 4);
        sort(ys, ys + 4);
        int s = xs[2] - xs[0];
        cout << s * s << '\n';
    }

    return 0;
}