#include <bits/stdc++.h> 
using namespace std;

#define ll long long  


int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll t; 
    cin >> t; 

    while (t--)
    {
        ll n, m; 
        cin >> n >> m; 

        vector<ll> a(n);
        for (ll i = 0; i < n; i++)
        {
            cin >> a[i];
        }
        ll count = 0;
        for (ll i = 0; i < n; i++)
        {
            if (a[i] == 1)
            {
                count++;
            }
        }
        if (count == 0)
        {
            cout << "NO" << endl;
            continue;
        }
        else
        {
            cout << "YES" << endl;
        }
    }
}