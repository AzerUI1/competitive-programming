#include <bits/stdc++.h>
#define int long long
using namespace std; 

int main(void) {
    int t; cin >> t; //a
    while (t--) {
        int m; cin >> m; 
        int p = 1; 
        while (p * 10 <= m) {
            p *= 10; 
        }
        cout << m - p << endl;
    }
    return 0;
}