# Read n and k
n, k = map(int, input().split())

# Read scores (non-increasing order)
scores = list(map(int, input().split()))

threshold = scores[k-1]  # k-th place score (1-indexed)

# Count participants who have score >= threshold and > 0
count = 0
for score in scores:
    if score >= threshold and score > 0:
        count += 1

print(count)
 