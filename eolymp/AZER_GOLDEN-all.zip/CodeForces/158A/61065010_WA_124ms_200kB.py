# OlympicTasksPython
import sys 
n, k = map(int, sys.stdin.readline().split()) 
a = list(map(int, sys.stdin.readline().split())) 
c = 0
for i in range(n - 1): 
    b = a[k]
    if a[i] >= b and b != 0: 
        c += 1 
    else: 
        if b == 0: 
            c = 0 
print(c) 