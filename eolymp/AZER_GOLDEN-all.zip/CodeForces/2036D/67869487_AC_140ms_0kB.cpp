#include <iostream>
#include <vector>
#include <string>

void solve() {
    int n, m; 
    std::cin >> n >> m;
    std::vector<std::string> a(n);
    for (int i = 0; i < n; ++i) std::cin >> a[i];
    
    int count = 0;
    for (int i = 0; (i + 1) * 2 <= n && (i + 1) * 2 <= m; ++i) {
        std::vector<char> layer;
        for (int j = i; j < m - i; ++j) layer.push_back(a[i][j]);
        for (int j = i + 1; j < n - i - 1; ++j) layer.push_back(a[j][m - i - 1]);
        for (int j = m - i - 1; j >= i; --j) layer.push_back(a[n - i - 1][j]);
        for (int j = n - i - 2; j >= i + 1; --j) layer.push_back(a[j][i]);
        
        int pos = layer.size();
        for (int j = 0; j < pos; ++j)
            if (layer[j] == '1' && layer[(j + 1) % pos] == '5' && layer[(j + 2) % pos] == '4' && layer[(j + 3) % pos] == '3')
                count++;
    }
    
    std::cout << count << "\n";
}

int main() {
    int t; std::cin >> t;
    while (t--) solve();
}