/** 
* @authr: Azer Aslanov;
*/

#include <bits/stdc++.h>

using namespace std;

#define FAST ios::sync_with_stdio(false); cin.tie(nullptr);

#define ll long long
#define ull unsigned long long
#define ld long double
#define pii pair<int, int>
#define pll pair<long long, long long>
#define vi vector<int>
#define vll vector<long long>
#define vb vector<bool>
#define vpi vector<pair<int, int>>
#define vpll vector<pair<long long, long long>>

#define rep(i, a, b) for (int i = (a); i < (b); i++)
#define rrep(i, a, b) for (int i = (a); i >= (b); i--)
#define each(x, a) for (auto &x : a)

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define pb push_back
#define mp make_pair
#define ff first
#define ss second

const int MOD = 1000000007;
const int MOD2 = 998244353;
const ll INF = 9e18;

#ifdef LOCAL
#define debug(x) cerr << #x << " = " << x << endl
#else
#define debug(x)
#endif

void solve() 
{
    ll n;
    cin >> n;

    if (n % 2 == 0)
    {
        cout << -1 << "\n";
        return;
    }

    for (ll i = 1; i <= n; i++)
    {
        ll x = (2LL * i) % n;
        if (x == 0) x = n;
        cout << x << " ";
    }

    cout << "\n";
}

int main() 
{
    FAST;

    ll t;
    cin >> t;

    while (t--)
    {
        solve();
    }

    return 0;
}