#include <bits/stdc++.h> 

#define pb push_back
#define ll long long 

using namespace std; 

int main() 
{
    ll t; 
    cin >> t; 
    
    while (t--) 
    {
        ll n; 
        cin >> n; 
        
        vecotr<ll> a(n); 
        
        for (ll i = 0; i < n; i++)
        {
            cin >> a[i]; 
        }
        
        cout << min(2*a[0], a[0] + a[1]) << "\n"; 
    }
    
    return 0; 
}