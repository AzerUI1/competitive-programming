#include <iostream>
#define int long long
using namespace std;
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        int x, y;
        cin >> x >> y;
        if (y % x != 0) {
            cout << "0 0\n";
            continue;
        }
        int b = y / x;
        if (b == 1) {
            cout << "3 1\n"; 
        } else {
            cout << "1 " << b << endl; 
        }
    }
    return 0;
}