#include <bits/stdc++.h>
using namespace std;

int main() {
    int t; cin >> t;
    while (t--) {
        int n, h, m;
        cin >> n >> h >> m;
        int b = h * 60 + m;
        int min_ = 24 * 60; 
        for (int i = 0; i < n; ++i) {
            int h, m;
            cin >> h >> m;
            int ala = h * 60 + m;
            int sle;
            if (ala >= b) {
                sle = ala - b;
            } else {
                sle = (24 * 60 - b) + ala;
            }

            min_ = min(min_, sle);
        }
        int sle = min_ / 60;
        int slee = min_ % 60;
        cout << sle << " " << slee << endl;
    }
}