#include <bits/stdc++.h>
using namespace std;
int main() {
    int t; cin >> t;
    while (t--) {
        int n, h, m;
        cin >> n >> h >> m;
        int b = h * 60 + m;
        int min = 24 * 60; 
        for (int i = 0; i < n; ++i) {
            int h, m;
            cin >> h >> m;
            int ala = h * 60 + m;
            int sle;
            if (ala >= b) {
                sle = ala - b;
            } else {
                sle = (24 * 60 - b) + ala;
            }

            min = min(min, sle);
        }
        int sle = min / 60;
        int slee = min % 60;
        cout << sle << " " << slee << endl;
    }
}