#include <iostream>
#include <vector>
#include <string>
 
std::vector<std::string> solve(int n) {
    std::string s = std::to_string(n);
    std::vector<std::string> l;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] != '0') {
            l.push_back(s[i] + std::string(s.size() - i - 1, '0'));
        }
    }
    return l;
}
 
int main() {
    int t;
    std::cin >> t;
    for (int i = 0; i < t; ++i) {
        int n;
        std::cin >> n;
        std::vector<std::string> l = solve(n);
        std::cout << l.size() << "\n";
        for (const auto& val : l) {
            std::cout << val << " ";
        }//a
        std::cout << "\n";
    }
    return 0;
}