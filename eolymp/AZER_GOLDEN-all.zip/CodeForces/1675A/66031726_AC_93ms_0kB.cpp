#include <iostream>
#define int long long
using namespace std;
signed main() {
    int t; cin >> t; 
    while (t--) {
        int a, b, c, x, y;
        cin >> a >> b >> c >> x >> y;
        int da = max(0LL, x - a);
        int db = max(0LL, y - b);
        if (da + db <= c) cout << "YES\n";
        else cout << "NO\n";
    }
}