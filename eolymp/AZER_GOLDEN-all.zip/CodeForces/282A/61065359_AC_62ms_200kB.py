n = int(input())  # number of statements
x = 0  # initial value of x

for _ in range(n):
    statement = input()
    if '++' in statement:
        x += 1
    else:
        x -= 1

print(x)
 