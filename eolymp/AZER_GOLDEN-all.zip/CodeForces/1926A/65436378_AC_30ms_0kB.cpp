#include <bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin >> t;
    while (t--) {
        string s;
        cin >> s;
        int count_a = count(s.begin(), s.end(), 'A');
        int count_b = count(s.begin(), s.end(), 'B');
        if (count_a < count_b) {
            cout << 'B' << endl;
        } else {
            cout << 'A' << endl;
        }
    }
    return 0;
}