#include <bits/stdc++.h>
using namespace std;
#define ll long long 
int s(int x) {
    return x > 0 ? 1 : -1;
}

int main() { //fsdfsdg
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll t;
    cin >> t;
    while (t--) {
        ll n;
        cin >> n;
        vector<ll> a(n);
        for (ll i = 0; i < n; i++) {
            cin >> a[i];
        }

        ll sum = 0;
        for (ll i = 0; i < n; i++) {
            ll cur = a[i];
            ll j = i;
            while (j < n && s(a[i]) == s(a[j])) {
                cur = max(cur, a[j]);
                j = j + 1;
            }
            sum = sum + cur;
            i = j - 1;
        }

        cout << sum << "\n";
    }

    return 0;
}
