#include <bits/stdc++.h> 
using namespace std; 

int sumArrayRecursive(long long arr[], long long size) { 
    if (size <= 0) { 
        return 0; 
    } 
    return arr[size - 1] + sumArrayRecursive(arr, size - 1); 
} 

int main() { 
    long long t; 
    cin >> t; 
    long long cases = 1;
    while (t--) { 
        long long n; 
        cin >> n; 
        long long a[n]; 
        for (int i = 0; i < n; i++) { 
            cin >> a[i]; 
        } 
        long long answer = sumArrayRecursive(a, n); 
        cout << "Case" << " " << cases << ":" << " " << answer << endl; 
        cases++; 
    } 
    return 0; 
}